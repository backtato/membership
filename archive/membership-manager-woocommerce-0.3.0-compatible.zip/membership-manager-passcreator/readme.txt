=== Membership Manager - Passcreator Add-on ===
Contributors: membership-manager
Tags: membership, wallet, passcreator, qr, cards
Requires at least: 6.2
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 0.3.1
License: GPLv2 or later

Add-on separato per collegare Membership Manager Core a Passcreator.

== Description ==

Questo plugin richiede Membership Manager Core 0.4.1+ con contratto pubblico 1.2.0.

Funzioni incluse:

* configurazione API base, API key/proxy token e template ID;
* mapping campi template;
* self-test Passcreator;
* creazione/aggiornamento tessera;
* salvataggio locale di pass_id/public_url;
* push manuale;
* emissione automatica opzionale quando un socio viene creato/aggiornato nel Core;
* invio branding associazione/team a tutte le tessere;
* pulsante bulk per aggiornare le tessere esistenti dopo cambio logo/colori.

== Branding ==

Il branding è gestito nel Core sotto Membership > Impostazioni > Branding associazione/team.

L'add-on invia a Passcreator:

* `urlToLogo`
* `urlToBackground`
* `urlToThumbnail`
* nome associazione/team
* colore primario
* colore secondario
* colore accento
* tema

== Changelog ==

= 0.3.1 =
* Reworked customization from per-member card profile to organization/team branding.
* Added bulk update for existing Passcreator cards after branding changes.

= 0.3.0 =
* Added first dynamic images support.

= 0.2.0 =
* Public Core contract usage.

= 0.1.0 =
* Prima versione add-on separato.
