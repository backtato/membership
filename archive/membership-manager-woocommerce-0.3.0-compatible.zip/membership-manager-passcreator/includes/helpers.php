<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function mmcpc_cap_manage() {
    if ( function_exists( 'mmc_cap_manage' ) ) {
        return mmc_cap_manage();
    }
    return apply_filters( 'mmcpc_cap_manage', 'manage_options' );
}

function mmcpc_table_cards() {
    global $wpdb;
    return $wpdb->prefix . 'mmc_passcreator_cards';
}

function mmcpc_get_option( $key, $default = '' ) {
    $opts = get_option( 'mmcpc_settings', array() );
    if ( ! is_array( $opts ) ) $opts = array();
    return array_key_exists( $key, $opts ) ? $opts[ $key ] : $default;
}

function mmcpc_settings() {
    $opts = get_option( 'mmcpc_settings', array() );
    $opts = is_array( $opts ) ? $opts : array();
    return wp_parse_args( $opts, array(
        'api_base'         => 'https://app.passcreator.com',
        'api_key'          => '',
        'proxy_token'      => '',
        'template_id'      => '',
        'auto_issue'       => '0',
        'field_first_name' => 'nome',
        'field_last_name'  => 'cognome',
        'field_expiry'     => 'scadenza',
        'field_email'      => 'email',
        'field_message'    => 'messaggio',
        'field_organization_name' => 'nome_associazione',
        'field_theme_key'         => 'tema_tessera',
        'field_primary_color'     => 'colore_primario',
        'field_secondary_color'   => 'colore_secondario',
        'field_accent_color'      => 'colore_accento',
        'field_bg_color'          => 'colore_sfondo',
        'field_text_color'        => 'colore_testo',
        'enable_dynamic_images' => '1',
        'push_on_issue'    => '0',
        'push_text'        => 'La tua tessera è stata aggiornata.',
    ) );
}

function mmcpc_normalize_email( $email ) {
    $email = trim( strtolower( (string) $email ) );
    return sanitize_email( $email );
}

function mmcpc_admin_nonce_action( $action ) {
    return 'mmcpc_' . sanitize_key( $action );
}

function mmcpc_log( $level, $message, array $context = array() ) {
    $logs = get_option( 'mmcpc_recent_logs', array() );
    $logs = is_array( $logs ) ? $logs : array();
    array_unshift( $logs, array(
        'time'    => current_time( 'mysql' ),
        'level'   => sanitize_key( $level ),
        'message' => sanitize_text_field( $message ),
        'context' => $context,
    ) );
    $logs = array_slice( $logs, 0, 50 );
    update_option( 'mmcpc_recent_logs', $logs, false );
}

function mmcpc_core_contract_available() {
    return defined( 'MMC_VERSION' ) && class_exists( 'MMC_API' ) && version_compare( MMC_API::contract_version(), '1.2.0', '>=' );
}
