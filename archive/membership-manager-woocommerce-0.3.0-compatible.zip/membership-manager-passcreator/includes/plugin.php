<?php
if ( ! defined( 'ABSPATH' ) ) exit;

final class MMCPC_Plugin {
    private static $instance = null;
    private $booted = false;
    private $provider = null;

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {}

    public function boot() {
        if ( $this->booted ) return;
        $this->booted = true;

        if ( ! mmcpc_core_contract_available() || ! interface_exists( 'MMC_Card_Provider_Interface' ) ) {
            add_action( 'admin_notices', array( $this, 'missing_core_notice' ) );
            return;
        }

        $this->load_files();
        $this->provider = new MMCPC_Passcreator_Provider();
        $this->register_hooks();
    }

    private function load_files() {
        require_once MMCPC_PATH . 'includes/api-client.php';
        require_once MMCPC_PATH . 'includes/card-store.php';
        require_once MMCPC_PATH . 'includes/provider-passcreator.php';
        require_once MMCPC_PATH . 'admin/admin.php';
    }

    private function register_hooks() {
        MMCPC_Admin::register();
        add_filter( 'mmc_card_provider', array( $this, 'register_provider' ) );
        add_filter( 'mmc_member_card_url', array( $this, 'member_card_url' ), 10, 2 );
        add_action( 'mmc_portal_after_member_card', array( $this, 'render_portal_card_link' ) );
        add_action( 'mmc_member_created', array( $this, 'maybe_auto_issue' ), 20, 2 );
        add_action( 'mmc_member_updated', array( $this, 'maybe_auto_issue' ), 20, 2 );
        add_action( 'mmc_organization_branding_updated', array( $this, 'sync_branding_to_existing_cards' ), 20, 2 );
    }

    public function provider() {
        return $this->provider;
    }

    public function register_provider( $provider ) {
        return $this->provider ?: $provider;
    }

    public function member_card_url( $url, $member ) {
        if ( ! $this->provider ) return $url;
        $pc_url = $this->provider->get_card_url( (array) $member );
        return $pc_url ? $pc_url : $url;
    }


    public function render_portal_card_link( $member ) {
        if ( ! $this->provider || ! is_array( $member ) ) return;
        $url = $this->provider->get_card_url( $member );
        if ( ! $url ) return;
        echo '<p><a class="button" href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html__( 'Apri tessera digitale', 'membership-manager-passcreator' ) . '</a></p>';
    }


    public function sync_branding_to_existing_cards( $branding, $old_branding ) {
        // Avoid heavy synchronous mass updates here. The admin page exposes an explicit bulk update button.
        mmcpc_log( 'info', 'Branding associazione aggiornato. Eseguire aggiorna tessere per propagare a Passcreator.', array( 'organization_name' => is_array( $branding ) ? ( $branding['organization_name'] ?? '' ) : '' ) );
    }

    public function maybe_auto_issue( $member_id, $payload ) {
        $settings = mmcpc_settings();
        if ( empty( $settings['auto_issue'] ) || '1' !== (string) $settings['auto_issue'] ) return;
        if ( ! $this->provider || ! class_exists( 'MMC_API' ) ) return;
        $member = MMC_API::get_member( $member_id );
        if ( ! $member ) return;
        $res = $this->provider->create_card( $member );
        if ( is_wp_error( $res ) ) {
            mmcpc_log( 'error', 'Emissione/aggiornamento automatico Passcreator fallito.', array( 'member_id' => $member_id, 'error' => $res->get_error_message() ) );
            return;
        }
        mmcpc_log( 'info', 'Tessera Passcreator emessa/aggiornata automaticamente.', array( 'member_id' => $member_id ) );
        if ( ! empty( $settings['push_on_issue'] ) && '1' === (string) $settings['push_on_issue'] ) {
            $this->provider->send_push( $member, $settings['push_text'] );
        }
    }

    public function missing_core_notice() {
        if ( ! current_user_can( 'activate_plugins' ) ) return;
        echo '<div class="notice notice-error"><p><strong>Membership Manager - Passcreator Add-on</strong>: ' . esc_html__( 'richiede Membership Manager Core 0.4.1+ con contratto pubblico 1.2.0 attivo.', 'membership-manager-passcreator' ) . '</p></div>';
    }
}
