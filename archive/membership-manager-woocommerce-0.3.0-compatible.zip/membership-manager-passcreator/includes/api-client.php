<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MMCPC_API_Client {
    private $settings;

    public function __construct( array $settings = array() ) {
        $this->settings = $settings ? $settings : mmcpc_settings();
    }

    public function api_root() {
        $base = rtrim( trim( (string) ( $this->settings['api_base'] ?? '' ) ), '/' );
        $base = preg_replace( '~/(api)(/v\d+)?$~i', '', $base );
        $base = preg_replace( '~/(en|de|fr|it)$~i', '', $base );
        if ( ! $this->api_base_is_allowed( $base ) ) {
            return '';
        }
        return $base . '/api';
    }

    private function api_base_is_allowed( $base ) {
        $p = wp_parse_url( $base );
        if ( ! is_array( $p ) ) return false;
        $scheme = strtolower( (string) ( $p['scheme'] ?? '' ) );
        $host   = strtolower( (string) ( $p['host'] ?? '' ) );
        $port   = isset( $p['port'] ) ? (int) $p['port'] : 0;
        if ( 'https' !== $scheme || '' === $host ) return false;
        if ( ! empty( $p['user'] ) || ! empty( $p['pass'] ) ) return false;
        if ( $port && 443 !== $port ) return false;
        return (bool) preg_match( '~(^|\.)passcreator\.com$~i', $host );
    }

    private function headers() {
        $proxy = trim( (string) ( $this->settings['proxy_token'] ?? '' ) );
        $key   = trim( (string) ( $this->settings['api_key'] ?? '' ) );
        $headers = array(
            'Content-Type' => 'application/json',
            'Accept'       => 'application/json',
        );
        if ( '' !== $proxy ) {
            $headers['Authorization'] = $proxy;
            return $headers;
        }
        if ( '' !== $key ) {
            $headers['Authorization'] = $key;
            $headers['ApiKey']        = $key;
        }
        return $headers;
    }

    public function request( $method, $url, $payload = null, $timeout = 30 ) {
        $root = $this->api_root();
        if ( '' === $root ) {
            return $this->error( 'API Base non valida o non autorizzata.', 0 );
        }

        $method = strtoupper( trim( (string) $method ) );
        if ( ! in_array( $method, array( 'GET', 'POST', 'PATCH', 'PUT', 'DELETE' ), true ) ) {
            return $this->error( 'Metodo HTTP non autorizzato.', 0 );
        }

        if ( function_exists( 'wp_http_validate_url' ) && ! wp_http_validate_url( $url ) ) {
            return $this->error( 'URL Passcreator non valida.', 0 );
        }

        $u = wp_parse_url( $url );
        $r = wp_parse_url( $root );
        if ( ! is_array( $u ) || ! is_array( $r ) || empty( $u['host'] ) || empty( $r['host'] ) ) {
            return $this->error( 'URL/API root non valida.', 0 );
        }
        if ( strtolower( (string) $u['scheme'] ) !== 'https' || strtolower( (string) $u['host'] ) !== strtolower( (string) $r['host'] ) ) {
            return $this->error( 'URL non autorizzata: host/scheme mismatch.', 0 );
        }
        $u_path = '/' . ltrim( (string) ( $u['path'] ?? '' ), '/' );
        $r_path = '/' . trim( (string) ( $r['path'] ?? '/api' ), '/' );
        if ( $u_path !== $r_path && strpos( $u_path, rtrim( $r_path, '/' ) . '/' ) !== 0 ) {
            return $this->error( 'URL non autorizzata: path fuori API root.', 0 );
        }

        $args = array(
            'method'             => $method,
            'timeout'            => max( 5, min( 90, (int) $timeout ) ),
            'headers'            => $this->headers(),
            'redirection'        => 0,
            'reject_unsafe_urls' => true,
        );
        if ( null !== $payload ) {
            $args['body'] = wp_json_encode( $payload );
        }

        $attempts = 0;
        $response = null;
        do {
            $attempts++;
            $response = wp_remote_request( $url, $args );
            if ( is_wp_error( $response ) ) {
                if ( $attempts < 3 ) { usleep( 250000 * $attempts ); continue; }
                return $this->error( $response->get_error_message(), 0, '', null, $attempts );
            }
            $code = (int) wp_remote_retrieve_response_code( $response );
            if ( in_array( $code, array( 429, 500, 502, 503, 504 ), true ) && $attempts < 3 ) {
                usleep( 250000 * $attempts );
                continue;
            }
            break;
        } while ( $attempts < 3 );

        $code = (int) wp_remote_retrieve_response_code( $response );
        $body = (string) wp_remote_retrieve_body( $response );
        $json = null;
        if ( '' !== $body ) {
            $tmp = json_decode( $body, true );
            if ( JSON_ERROR_NONE === json_last_error() ) $json = $tmp;
        }
        if ( $code >= 200 && $code < 300 ) {
            return array( 'ok' => true, 'code' => $code, 'body' => $body, 'json' => $json, 'attempts' => $attempts );
        }
        $message = $this->extract_error_message( $json, $body, $code );
        return $this->error( $message, $code, $body, $json, $attempts );
    }

    private function extract_error_message( $json, $body, $code ) {
        if ( is_array( $json ) ) {
            $msg = (string) ( $json['message'] ?? ( $json['error'] ?? '' ) );
            if ( '' === $msg && isset( $json['errors'] ) ) $msg = wp_json_encode( $json['errors'] );
            if ( '' === $msg ) $msg = wp_json_encode( $json );
            return $msg;
        }
        $body = trim( (string) $body );
        return '' !== $body ? $body : 'HTTP ' . (int) $code;
    }

    private function classify_error( $code, $message ) {
        $code = (int) $code;
        $msg = strtolower( (string) $message );
        if ( 0 === $code ) return array( 'diagnostic' => 'Errore rete/connessione o API base non valida.', 'retryable' => true );
        if ( in_array( $code, array( 429, 500, 502, 503, 504 ), true ) ) return array( 'diagnostic' => 'Errore temporaneo/rate limit Passcreator.', 'retryable' => true );
        if ( in_array( $code, array( 401, 403 ), true ) ) return array( 'diagnostic' => 'Autenticazione Passcreator fallita.', 'retryable' => false );
        if ( 404 === $code ) return array( 'diagnostic' => 'Risorsa Passcreator non trovata.', 'retryable' => false );
        if ( strpos( $msg, 'custom number' ) !== false || strpos( $msg, 'defined range' ) !== false ) return array( 'diagnostic' => 'Range numeri personalizzati Passcreator esaurito.', 'retryable' => false );
        if ( strpos( $msg, 'expiration' ) !== false || strpos( $msg, 'date' ) !== false ) return array( 'diagnostic' => 'Formato scadenza non accettato.', 'retryable' => false );
        if ( strpos( $msg, 'template' ) !== false ) return array( 'diagnostic' => 'Template/campi Passcreator da verificare.', 'retryable' => false );
        return array( 'diagnostic' => 'Errore Passcreator non classificato.', 'retryable' => false );
    }

    private function error( $message, $code, $body = '', $json = null, $attempts = 1 ) {
        $class = $this->classify_error( $code, $message );
        return array(
            'ok'         => false,
            'error'      => (string) $message,
            'code'       => (int) $code,
            'body'       => (string) $body,
            'json'       => $json,
            'attempts'   => (int) $attempts,
            'diagnostic' => $class['diagnostic'],
            'retryable'  => ! empty( $class['retryable'] ),
        );
    }

    public function self_test() {
        $root = $this->api_root();
        $out = array( 'ok' => false, 'api_root' => $root, 'checks' => array() );
        if ( '' === $root ) {
            $out['error'] = 'API Base non valida o non autorizzata.';
            return $out;
        }
        $r1 = $this->request( 'GET', $root . '/v3/pass?pageSize=10', null, 25 );
        $out['checks']['v3_pass_list'] = $this->compact_result( $r1 );
        if ( empty( $r1['ok'] ) ) {
            $out['error'] = 'Check v3/pass fallito: ' . (string) ( $r1['error'] ?? '' );
            return $out;
        }
        $template_id = trim( (string) ( $this->settings['template_id'] ?? '' ) );
        if ( '' !== $template_id ) {
            $r2 = $this->request( 'GET', $root . '/v2/pass-template/' . rawurlencode( $template_id ) . '/describe', null, 25 );
            if ( empty( $r2['ok'] ) ) {
                $r2_old = $this->request( 'GET', $root . '/v2/template/' . rawurlencode( $template_id ), null, 25 );
                if ( ! empty( $r2_old['ok'] ) ) $r2 = $r2_old;
            }
            $out['checks']['v2_template'] = $this->compact_result( $r2 );
            if ( empty( $r2['ok'] ) ) {
                $out['error'] = 'Check template fallito: ' . (string) ( $r2['error'] ?? '' );
                return $out;
            }
        } else {
            $out['checks']['v2_template'] = array( 'ok' => true, 'skipped' => true, 'note' => 'Template ID non configurato.' );
        }
        $out['ok'] = true;
        return $out;
    }

    private function compact_result( $r ) {
        return array(
            'ok'         => ! empty( $r['ok'] ),
            'code'       => (int) ( $r['code'] ?? 0 ),
            'error'      => (string) ( $r['error'] ?? '' ),
            'diagnostic' => (string) ( $r['diagnostic'] ?? '' ),
            'attempts'   => (int) ( $r['attempts'] ?? 1 ),
            'retryable'  => ! empty( $r['retryable'] ),
        );
    }
}
