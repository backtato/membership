<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MMCPC_Activator {
    public static function activate() {
        self::create_tables();
        update_option( 'mmcpc_db_version', MMCPC_DB_VERSION, false );
    }

    public static function deactivate() {
        // Nessun cleanup distruttivo alla disattivazione.
    }

    private static function create_tables() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset_collate = $wpdb->get_charset_collate();
        $cards = mmcpc_table_cards();

        $sql = "CREATE TABLE {$cards} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            member_id BIGINT UNSIGNED NOT NULL,
            email VARCHAR(190) NOT NULL,
            pass_id VARCHAR(190) DEFAULT '' NOT NULL,
            public_url TEXT NULL,
            pass_barcode VARCHAR(190) DEFAULT '' NOT NULL,
            status VARCHAR(40) DEFAULT 'pending' NOT NULL,
            last_error TEXT NULL,
            raw_response LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY member_id (member_id),
            KEY email (email),
            KEY pass_id (pass_id),
            KEY status (status)
        ) {$charset_collate};";

        dbDelta( $sql );
    }
}
