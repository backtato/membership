<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MMCPC_Card_Store {
    public static function get_by_member_id( $member_id ) {
        global $wpdb;
        $member_id = absint( $member_id );
        if ( ! $member_id ) return null;
        $row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . mmcpc_table_cards() . ' WHERE member_id = %d LIMIT 1', $member_id ), ARRAY_A );
        return $row ?: null;
    }

    public static function get_by_email( $email ) {
        global $wpdb;
        $email = mmcpc_normalize_email( $email );
        if ( ! is_email( $email ) ) return null;
        $row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . mmcpc_table_cards() . ' WHERE email = %s LIMIT 1', $email ), ARRAY_A );
        return $row ?: null;
    }

    public static function upsert( $member_id, $email, array $data ) {
        global $wpdb;
        $member_id = absint( $member_id );
        $email = mmcpc_normalize_email( $email );
        if ( ! $member_id || ! is_email( $email ) ) {
            return new WP_Error( 'mmcpc_invalid_card_ref', __( 'Riferimento tessera non valido.', 'membership-manager-passcreator' ) );
        }
        $now = current_time( 'mysql' );
        $payload = array(
            'member_id'    => $member_id,
            'email'        => $email,
            'pass_id'      => isset( $data['pass_id'] ) ? sanitize_text_field( $data['pass_id'] ) : '',
            'public_url'   => isset( $data['public_url'] ) ? esc_url_raw( $data['public_url'] ) : '',
            'pass_barcode' => isset( $data['pass_barcode'] ) ? sanitize_text_field( $data['pass_barcode'] ) : '',
            'status'       => isset( $data['status'] ) ? sanitize_key( $data['status'] ) : 'pending',
            'last_error'   => isset( $data['last_error'] ) ? sanitize_textarea_field( $data['last_error'] ) : '',
            'raw_response' => isset( $data['raw_response'] ) ? wp_json_encode( $data['raw_response'] ) : '',
            'updated_at'   => $now,
        );
        $existing = self::get_by_member_id( $member_id );
        if ( $existing ) {
            $ok = $wpdb->update( mmcpc_table_cards(), $payload, array( 'member_id' => $member_id ) );
            return false === $ok ? new WP_Error( 'mmcpc_card_update_failed', __( 'Aggiornamento dati Passcreator non riuscito.', 'membership-manager-passcreator' ) ) : true;
        }
        $payload['created_at'] = $now;
        $ok = $wpdb->insert( mmcpc_table_cards(), $payload );
        return false === $ok ? new WP_Error( 'mmcpc_card_insert_failed', __( 'Salvataggio dati Passcreator non riuscito.', 'membership-manager-passcreator' ) ) : true;
    }

    public static function mark_error( $member_id, $email, $error, array $raw = array() ) {
        return self::upsert( $member_id, $email, array(
            'status'       => 'error',
            'last_error'   => $error,
            'raw_response' => $raw,
        ) );
    }

    public static function list_recent( $limit = 50 ) {
        global $wpdb;
        $limit = max( 1, min( 200, absint( $limit ) ) );
        return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . mmcpc_table_cards() . ' ORDER BY updated_at DESC LIMIT %d', $limit ), ARRAY_A );
    }
}
