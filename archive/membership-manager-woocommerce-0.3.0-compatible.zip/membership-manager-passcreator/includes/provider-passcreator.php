<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MMCPC_Passcreator_Provider implements MMC_Card_Provider_Interface {
    private $settings;
    private $client;

    public function __construct( array $settings = array() ) {
        $this->settings = $settings ? $settings : mmcpc_settings();
        $this->client = new MMCPC_API_Client( $this->settings );
    }

    public function create_card( array $member ) {
        return $this->create_or_update_card( $member );
    }

    public function update_card( array $member ) {
        return $this->create_or_update_card( $member );
    }

    public function revoke_card( array $member ) {
        $card = MMCPC_Card_Store::get_by_member_id( (int) ( $member['id'] ?? 0 ) );
        $pass_id = $card ? trim( (string) $card['pass_id'] ) : '';
        if ( '' === $pass_id ) {
            return new WP_Error( 'mmcpc_missing_pass_id', __( 'Pass ID mancante.', 'membership-manager-passcreator' ) );
        }
        $root = $this->client->api_root();
        $urls = array(
            $root . '/v3/pass/' . rawurlencode( $pass_id ),
            $root . '/pass/' . rawurlencode( $pass_id ),
        );
        $last = null;
        foreach ( $urls as $url ) {
            $r = $this->client->request( 'DELETE', $url, null, 30 );
            $last = $r;
            if ( ! empty( $r['ok'] ) || in_array( (int) ( $r['code'] ?? 0 ), array( 404, 410 ), true ) ) {
                MMCPC_Card_Store::upsert( (int) $member['id'], $member['email'], array( 'status' => 'revoked', 'pass_id' => $pass_id ) );
                return true;
            }
            if ( ! in_array( (int) ( $r['code'] ?? 0 ), array( 400, 405 ), true ) ) break;
        }
        return new WP_Error( 'mmcpc_revoke_failed', (string) ( $last['error'] ?? __( 'Revoca fallita.', 'membership-manager-passcreator' ) ) );
    }

    public function get_card_url( array $member ) {
        $card = MMCPC_Card_Store::get_by_member_id( (int) ( $member['id'] ?? 0 ) );
        return $card ? esc_url_raw( (string) $card['public_url'] ) : '';
    }

    public function send_push( array $member, $message ) {
        $card = MMCPC_Card_Store::get_by_member_id( (int) ( $member['id'] ?? 0 ) );
        $pass_id = $card ? trim( (string) $card['pass_id'] ) : '';
        if ( '' === $pass_id ) return new WP_Error( 'mmcpc_missing_pass_id', __( 'Pass ID mancante.', 'membership-manager-passcreator' ) );
        $root = $this->client->api_root();
        $payload = array( 'pushNotificationText' => sanitize_text_field( $message ) );
        $r = $this->client->request( 'POST', $root . '/pass/' . rawurlencode( $pass_id ) . '/sendpushnotification', $payload, 30 );
        if ( ! empty( $r['ok'] ) || 304 === (int) ( $r['code'] ?? 0 ) ) {
            return array( 'ok' => true, 'duplicate' => 304 === (int) ( $r['code'] ?? 0 ) );
        }
        return new WP_Error( 'mmcpc_push_failed', (string) ( $r['error'] ?? __( 'Push fallita.', 'membership-manager-passcreator' ) ), $r );
    }

    private function create_or_update_card( array $member ) {
        $member_id = absint( $member['id'] ?? 0 );
        $email = mmcpc_normalize_email( $member['email'] ?? '' );
        if ( ! $member_id || ! is_email( $email ) ) {
            return new WP_Error( 'mmcpc_invalid_member', __( 'Socio non valido.', 'membership-manager-passcreator' ) );
        }
        $template_id = trim( (string) ( $this->settings['template_id'] ?? '' ) );
        if ( '' === $template_id ) {
            return new WP_Error( 'mmcpc_missing_template', __( 'Template ID Passcreator mancante.', 'membership-manager-passcreator' ) );
        }
        $known = MMCPC_Card_Store::get_by_member_id( $member_id );
        $known_pass_id = $known ? trim( (string) $known['pass_id'] ) : '';
        $data = $this->build_pass_data( $member );
        $root = $this->client->api_root();
        if ( '' === $root ) return new WP_Error( 'mmcpc_invalid_api_base', __( 'API Base Passcreator non valida.', 'membership-manager-passcreator' ) );

        if ( '' !== $known_pass_id ) {
            $patched = $this->patch_pass_fields( $known_pass_id, $data );
            if ( ! is_wp_error( $patched ) ) return $patched;
            $code = (int) $patched->get_error_data( 'code' );
            if ( ! in_array( $code, array( 404, 410 ), true ) ) return $patched;
        }

        $found = $this->find_existing_pass( $email, $template_id );
        if ( ! is_wp_error( $found ) && ! empty( $found['pass_id'] ) ) {
            $patched = $this->patch_pass_fields( $found['pass_id'], $data, $found );
            if ( ! is_wp_error( $patched ) ) return $patched;
            return $patched;
        } elseif ( is_wp_error( $found ) && 'mmcpc_pass_not_found' !== $found->get_error_code() ) {
            return $found;
        }

        $create_data = $data;
        $create_data['templateId'] = $template_id;
        $create_data['enforceUniqueUserProvidedId'] = true;
        $r = $this->client->request( 'POST', $root . '/v3/pass?async=false', array( 'data' => $create_data ), 60 );
        if ( empty( $r['ok'] ) ) {
            $err = (string) ( $r['error'] ?? '' );
            if ( in_array( (int) ( $r['code'] ?? 0 ), array( 400, 409 ), true ) && preg_match( '/duplicate|already|userprovidedid|unique|conflict/i', $err ) ) {
                $found2 = $this->find_existing_pass( $email, $template_id );
                if ( ! is_wp_error( $found2 ) && ! empty( $found2['pass_id'] ) ) {
                    return $this->patch_pass_fields( $found2['pass_id'], $data, $found2 );
                }
            }
            MMCPC_Card_Store::mark_error( $member_id, $email, $err, $r );
            return new WP_Error( 'mmcpc_create_failed', $err, $r );
        }
        return $this->store_identity_from_response( $member, $r['json'] ?? array(), 'active' );
    }

    private function build_pass_data( array $member ) {
        $data = array( 'userProvidedId' => mmcpc_normalize_email( $member['email'] ?? '' ) );
        $map = array(
            'field_first_name' => $member['first_name'] ?? '',
            'field_last_name'  => $member['last_name'] ?? '',
            'field_email'      => $member['email'] ?? '',
            'field_expiry'     => $member['expiry_date'] ?? '',
        );
        foreach ( $map as $setting_key => $value ) {
            $field = trim( (string) ( $this->settings[ $setting_key ] ?? '' ) );
            if ( '' !== $field ) $data[ $field ] = (string) $value;
        }
        $expiration = $this->normalize_expiration_datetime( $member['expiry_date'] ?? '' );
        if ( '' !== $expiration ) $data['expirationDate'] = $expiration;

        $branding_fields = ( class_exists( 'MMC_API' ) && method_exists( 'MMC_API', 'get_organization_branding_pass_fields' ) ) ? MMC_API::get_organization_branding_pass_fields() : array();
        if ( is_array( $branding_fields ) && ! empty( $branding_fields ) ) {
            if ( ! empty( $this->settings['enable_dynamic_images'] ) && '1' === (string) $this->settings['enable_dynamic_images'] ) {
                foreach ( array( 'urlToLogo', 'urlToBackground', 'urlToThumbnail' ) as $image_key ) {
                    if ( ! empty( $branding_fields[ $image_key ] ) ) {
                        $data[ $image_key ] = esc_url_raw( $branding_fields[ $image_key ] );
                    }
                }
            }

            $brand_map = array(
                'field_organization_name' => $branding_fields['organization_name'] ?? '',
                'field_theme_key'         => $branding_fields['theme_key'] ?? '',
                'field_primary_color'     => $branding_fields['primary_color'] ?? '',
                'field_secondary_color'   => $branding_fields['secondary_color'] ?? '',
                'field_accent_color'      => $branding_fields['accent_color'] ?? '',
                // Backward compatibility with older mapping labels.
                'field_bg_color'          => $branding_fields['brand_color'] ?? ( $branding_fields['primary_color'] ?? '' ),
                'field_text_color'        => $branding_fields['secondary_color'] ?? '',
            );
            foreach ( $brand_map as $setting_key => $value ) {
                $field = trim( (string) ( $this->settings[ $setting_key ] ?? '' ) );
                if ( '' !== $field && '' !== (string) $value ) $data[ $field ] = (string) $value;
            }
        }

        return apply_filters( 'mmcpc_pass_data', $data, $member, $this );
    }

    private function normalize_expiration_datetime( $input ) {
        $s = trim( (string) $input );
        if ( '' === $s ) return '';
        if ( preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(Z|[+\-]\d{2}:\d{2})$/', $s ) ) return $s;
        $tz = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'UTC' );
        try {
            if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $s ) ) {
                return ( new DateTimeImmutable( $s . ' 23:59:59', $tz ) )->format( 'Y-m-d\TH:i:sP' );
            }
            $ts = strtotime( $s );
            if ( false !== $ts ) return ( new DateTimeImmutable( '@' . $ts ) )->setTimezone( $tz )->format( 'Y-m-d\TH:i:sP' );
        } catch ( Exception $e ) {
            return '';
        }
        return '';
    }

    private function patch_pass_fields( $pass_id, array $data, array $fallback = array() ) {
        $root = $this->client->api_root();
        $r = $this->client->request( 'PATCH', $root . '/v3/pass/' . rawurlencode( $pass_id ) . '?async=false', array( 'data' => $data ), 60 );
        if ( empty( $r['ok'] ) ) return new WP_Error( 'mmcpc_patch_failed', (string) ( $r['error'] ?? '' ), $r );
        $raw = is_array( $r['json'] ?? null ) ? ( $r['json']['data'] ?? $r['json'] ) : array();
        if ( empty( $raw['downloadPage'] ) && empty( $raw['publicUrl'] ) && ! empty( $fallback ) ) {
            $raw['downloadPage'] = $fallback['public_url'] ?? '';
        }
        return $this->store_identity_from_raw( $data['userProvidedId'], $pass_id, $raw, 'active' );
    }

    private function find_existing_pass( $email, $template_id ) {
        $root = $this->client->api_root();
        $query = array(
            'templateId' => $template_id,
            'groups' => array( array( array( 'field' => 'userProvidedId', 'operator' => 'equals', 'value' => array( $email ) ) ) ),
        );
        $encoded = rtrim( strtr( base64_encode( wp_json_encode( $query ) ), '+/', '-_' ), '=' );
        $fields = 'identifier,downloadPage,publicUrl,createdOn,modifiedOn,userProvidedId,barcodeValue,barcode,serialNumber';
        $url = $root . '/v3/pass?pageSize=10&fields=' . rawurlencode( $fields ) . '&query=' . rawurlencode( $encoded );
        $r = $this->client->request( 'GET', $url, null, 30 );
        if ( empty( $r['ok'] ) ) return new WP_Error( 'mmcpc_search_failed', (string) ( $r['error'] ?? '' ), $r );
        $data = is_array( $r['json'] ?? null ) ? ( $r['json']['data'] ?? $r['json'] ) : array();
        $items = isset( $data['items'] ) && is_array( $data['items'] ) ? $data['items'] : ( is_array( $data ) ? $data : array() );
        foreach ( $items as $it ) {
            if ( ! is_array( $it ) ) continue;
            $id = (string) ( $it['identifier'] ?? ( $it['id'] ?? '' ) );
            if ( '' === $id ) continue;
            $upi = mmcpc_normalize_email( $it['userProvidedId'] ?? '' );
            if ( '' !== $upi && $upi !== $email ) continue;
            return array( 'pass_id' => $id, 'public_url' => (string) ( $it['downloadPage'] ?? ( $it['publicUrl'] ?? '' ) ), 'raw' => $it );
        }
        return new WP_Error( 'mmcpc_pass_not_found', __( 'Pass non trovato.', 'membership-manager-passcreator' ) );
    }

    private function store_identity_from_response( array $member, $json, $status ) {
        $raw = is_array( $json ) ? ( $json['data'] ?? $json ) : array();
        return $this->store_identity_from_raw( $member['email'] ?? '', '', $raw, $status );
    }

    private function store_identity_from_raw( $email, $fallback_pass_id, array $raw, $status ) {
        $email = mmcpc_normalize_email( $email );
        $member = class_exists( 'MMC_API' ) ? MMC_API::get_member_by_email( $email ) : null;
        if ( ! $member ) return new WP_Error( 'mmcpc_member_missing', __( 'Socio Core non trovato.', 'membership-manager-passcreator' ) );
        $pass_id = (string) ( $raw['identifier'] ?? ( $raw['id'] ?? $fallback_pass_id ) );
        $public = (string) ( $raw['downloadPage'] ?? ( $raw['publicUrl'] ?? '' ) );
        if ( '' === $public && '' !== $pass_id ) {
            $g = $this->client->request( 'GET', $this->client->api_root() . '/v3/pass/' . rawurlencode( $pass_id ), null, 30 );
            if ( ! empty( $g['ok'] ) && is_array( $g['json'] ?? null ) ) {
                $graw = $g['json']['data'] ?? $g['json'];
                if ( is_array( $graw ) ) {
                    $public = (string) ( $graw['downloadPage'] ?? ( $graw['publicUrl'] ?? '' ) );
                    $raw = array_merge( $raw, $graw );
                }
            }
        }
        if ( '' === $pass_id || '' === $public ) {
            MMCPC_Card_Store::mark_error( (int) $member['id'], $email, 'Risposta Passcreator senza identifier o publicUrl/downloadPage.', $raw );
            return new WP_Error( 'mmcpc_incomplete_response', __( 'Risposta Passcreator incompleta.', 'membership-manager-passcreator' ), $raw );
        }
        $barcode = $this->extract_barcode( $raw );
        $saved = MMCPC_Card_Store::upsert( (int) $member['id'], $email, array(
            'pass_id'      => $pass_id,
            'public_url'   => $public,
            'pass_barcode' => $barcode,
            'status'       => $status,
            'last_error'   => '',
            'raw_response' => $raw,
        ) );
        if ( is_wp_error( $saved ) ) return $saved;
        return array( 'ok' => true, 'passId' => $pass_id, 'publicUrl' => $public, 'passBarcode' => $barcode );
    }

    private function extract_barcode( array $raw ) {
        foreach ( array( 'barcodeValue', 'serialNumber', 'generatedId', 'generatedIdentifier' ) as $key ) {
            if ( ! empty( $raw[ $key ] ) && is_scalar( $raw[ $key ] ) ) return sanitize_text_field( (string) $raw[ $key ] );
        }
        if ( ! empty( $raw['barcode'] ) && is_array( $raw['barcode'] ) ) {
            foreach ( array( 'value', 'barcodeValue', 'serialNumber' ) as $key ) {
                if ( ! empty( $raw['barcode'][ $key ] ) && is_scalar( $raw['barcode'][ $key ] ) ) return sanitize_text_field( (string) $raw['barcode'][ $key ] );
            }
        }
        return '';
    }
}
