# Passcreator Add-on — Core Contract Usage

Questo add-on richiede Membership Manager Core 0.4.1+ con `MMC_API` contratto 1.2.0.

Dipendenze pubbliche usate:

- `MMC_API::get_member()`
- `MMC_API::get_member_by_email()`
- `MMC_API::list_members()`
- `MMC_API::get_organization_branding_pass_fields()`
- `MMC_Card_Provider_Interface`
- filtro `mmc_card_provider`
- filtro `mmc_member_card_url`
- azioni `mmc_member_created`, `mmc_member_updated`, `mmc_organization_branding_updated`, `mmc_portal_after_member_card`

Non deve chiamare direttamente `MMC_Member_Repository` né tabelle interne del Core.
