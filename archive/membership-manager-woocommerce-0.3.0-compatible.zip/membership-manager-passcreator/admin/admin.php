<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MMCPC_Admin {
    public static function register() {
        add_action( 'admin_menu', array( __CLASS__, 'menu' ), 20 );
        add_action( 'admin_post_mmcpc_save_settings', array( __CLASS__, 'save_settings' ) );
        add_action( 'admin_post_mmcpc_self_test', array( __CLASS__, 'self_test' ) );
        add_action( 'admin_post_mmcpc_issue_card', array( __CLASS__, 'issue_card' ) );
        add_action( 'admin_post_mmcpc_push_card', array( __CLASS__, 'push_card' ) );
        add_action( 'admin_post_mmcpc_update_all_branding', array( __CLASS__, 'update_all_branding' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
    }

    public static function menu() {
        add_submenu_page(
            'mmc-membership',
            __( 'Passcreator', 'membership-manager-passcreator' ),
            __( 'Passcreator', 'membership-manager-passcreator' ),
            mmcpc_cap_manage(),
            'mmc-passcreator',
            array( __CLASS__, 'render' )
        );
    }

    public static function assets( $hook ) {
        if ( false === strpos( (string) $hook, 'mmc-passcreator' ) ) return;
        wp_enqueue_style( 'mmcpc-admin', MMCPC_URL . 'assets/css/admin.css', array(), MMCPC_VERSION );
    }

    public static function save_settings() {
        if ( ! current_user_can( mmcpc_cap_manage() ) || ! check_admin_referer( mmcpc_admin_nonce_action( 'save_settings' ) ) ) {
            wp_die( esc_html__( 'Permesso negato.', 'membership-manager-passcreator' ) );
        }
        $old = mmcpc_settings();
        $api_key = isset( $_POST['api_key'] ) && '' !== (string) $_POST['api_key'] ? wp_unslash( $_POST['api_key'] ) : ( $old['api_key'] ?? '' );
        $proxy = isset( $_POST['proxy_token'] ) && '' !== (string) $_POST['proxy_token'] ? wp_unslash( $_POST['proxy_token'] ) : ( $old['proxy_token'] ?? '' );
        $settings = array(
            'api_base'         => isset( $_POST['api_base'] ) ? esc_url_raw( wp_unslash( $_POST['api_base'] ) ) : '',
            'api_key'          => sanitize_text_field( $api_key ),
            'proxy_token'      => sanitize_text_field( $proxy ),
            'template_id'      => isset( $_POST['template_id'] ) ? sanitize_text_field( wp_unslash( $_POST['template_id'] ) ) : '',
            'auto_issue'       => ! empty( $_POST['auto_issue'] ) ? '1' : '0',
            'field_first_name' => isset( $_POST['field_first_name'] ) ? sanitize_key( wp_unslash( $_POST['field_first_name'] ) ) : 'nome',
            'field_last_name'  => isset( $_POST['field_last_name'] ) ? sanitize_key( wp_unslash( $_POST['field_last_name'] ) ) : 'cognome',
            'field_email'      => isset( $_POST['field_email'] ) ? sanitize_key( wp_unslash( $_POST['field_email'] ) ) : 'email',
            'field_expiry'     => isset( $_POST['field_expiry'] ) ? sanitize_key( wp_unslash( $_POST['field_expiry'] ) ) : 'scadenza',
            'field_message'    => isset( $_POST['field_message'] ) ? sanitize_key( wp_unslash( $_POST['field_message'] ) ) : 'messaggio',
            'field_organization_name' => isset( $_POST['field_organization_name'] ) ? sanitize_key( wp_unslash( $_POST['field_organization_name'] ) ) : 'nome_associazione',
            'field_theme_key'         => isset( $_POST['field_theme_key'] ) ? sanitize_key( wp_unslash( $_POST['field_theme_key'] ) ) : 'tema_tessera',
            'field_primary_color'     => isset( $_POST['field_primary_color'] ) ? sanitize_key( wp_unslash( $_POST['field_primary_color'] ) ) : 'colore_primario',
            'field_secondary_color'   => isset( $_POST['field_secondary_color'] ) ? sanitize_key( wp_unslash( $_POST['field_secondary_color'] ) ) : 'colore_secondario',
            'field_accent_color'      => isset( $_POST['field_accent_color'] ) ? sanitize_key( wp_unslash( $_POST['field_accent_color'] ) ) : 'colore_accento',
            'field_bg_color'          => isset( $_POST['field_bg_color'] ) ? sanitize_key( wp_unslash( $_POST['field_bg_color'] ) ) : 'colore_sfondo',
            'field_text_color'        => isset( $_POST['field_text_color'] ) ? sanitize_key( wp_unslash( $_POST['field_text_color'] ) ) : 'colore_testo',
            'enable_dynamic_images' => ! empty( $_POST['enable_dynamic_images'] ) ? '1' : '0',
            'push_on_issue'    => ! empty( $_POST['push_on_issue'] ) ? '1' : '0',
            'push_text'        => isset( $_POST['push_text'] ) ? sanitize_text_field( wp_unslash( $_POST['push_text'] ) ) : '',
        );
        update_option( 'mmcpc_settings', $settings, false );
        wp_safe_redirect( add_query_arg( 'mmcpc_saved', '1', admin_url( 'admin.php?page=mmc-passcreator' ) ) );
        exit;
    }

    public static function self_test() {
        if ( ! current_user_can( mmcpc_cap_manage() ) || ! check_admin_referer( mmcpc_admin_nonce_action( 'self_test' ) ) ) {
            wp_die( esc_html__( 'Permesso negato.', 'membership-manager-passcreator' ) );
        }
        $client = new MMCPC_API_Client();
        update_option( 'mmcpc_last_self_test', $client->self_test(), false );
        wp_safe_redirect( add_query_arg( 'mmcpc_tested', '1', admin_url( 'admin.php?page=mmc-passcreator' ) ) );
        exit;
    }

    public static function issue_card() {
        if ( ! current_user_can( mmcpc_cap_manage() ) || ! check_admin_referer( mmcpc_admin_nonce_action( 'issue_card' ) ) ) {
            wp_die( esc_html__( 'Permesso negato.', 'membership-manager-passcreator' ) );
        }
        $member_id = isset( $_POST['member_id'] ) ? absint( $_POST['member_id'] ) : 0;
        $member = class_exists( 'MMC_API' ) ? MMC_API::get_member( $member_id ) : null;
        if ( ! $member ) {
            wp_safe_redirect( add_query_arg( 'mmcpc_error', rawurlencode( 'Socio non trovato.' ), admin_url( 'admin.php?page=mmc-passcreator' ) ) );
            exit;
        }
        $provider = new MMCPC_Passcreator_Provider();
        $res = $provider->create_card( $member );
        $arg = is_wp_error( $res ) ? array( 'mmcpc_error' => rawurlencode( $res->get_error_message() ) ) : array( 'mmcpc_issued' => '1' );
        wp_safe_redirect( add_query_arg( $arg, admin_url( 'admin.php?page=mmc-passcreator' ) ) );
        exit;
    }

    public static function push_card() {
        if ( ! current_user_can( mmcpc_cap_manage() ) || ! check_admin_referer( mmcpc_admin_nonce_action( 'push_card' ) ) ) {
            wp_die( esc_html__( 'Permesso negato.', 'membership-manager-passcreator' ) );
        }
        $member_id = isset( $_POST['member_id'] ) ? absint( $_POST['member_id'] ) : 0;
        $message = isset( $_POST['message'] ) ? sanitize_text_field( wp_unslash( $_POST['message'] ) ) : '';
        $member = class_exists( 'MMC_API' ) ? MMC_API::get_member( $member_id ) : null;
        if ( ! $member ) {
            wp_safe_redirect( add_query_arg( 'mmcpc_error', rawurlencode( 'Socio non trovato.' ), admin_url( 'admin.php?page=mmc-passcreator' ) ) );
            exit;
        }
        $provider = new MMCPC_Passcreator_Provider();
        $res = $provider->send_push( $member, $message );
        $arg = is_wp_error( $res ) ? array( 'mmcpc_error' => rawurlencode( $res->get_error_message() ) ) : array( 'mmcpc_pushed' => '1' );
        wp_safe_redirect( add_query_arg( $arg, admin_url( 'admin.php?page=mmc-passcreator' ) ) );
        exit;
    }

    public static function update_all_branding() {
        if ( ! current_user_can( mmcpc_cap_manage() ) || ! check_admin_referer( mmcpc_admin_nonce_action( 'update_all_branding' ) ) ) {
            wp_die( esc_html__( 'Permesso negato.', 'membership-manager-passcreator' ) );
        }
        $provider = new MMCPC_Passcreator_Provider();
        $cards = MMCPC_Card_Store::list_recent( 500 );
        $ok = 0;
        $fail = 0;
        foreach ( $cards as $card ) {
            $member = class_exists( 'MMC_API' ) ? MMC_API::get_member( absint( $card['member_id'] ) ) : null;
            if ( ! $member ) { $fail++; continue; }
            $res = $provider->update_card( $member );
            if ( is_wp_error( $res ) ) {
                $fail++;
                mmcpc_log( 'error', 'Aggiornamento branding tessera fallito.', array( 'member_id' => absint( $card['member_id'] ), 'error' => $res->get_error_message() ) );
            } else {
                $ok++;
            }
        }
        wp_safe_redirect( add_query_arg( array( 'mmcpc_bulk_branding' => '1', 'ok' => $ok, 'fail' => $fail ), admin_url( 'admin.php?page=mmc-passcreator' ) ) );
        exit;
    }

    public static function render() {
        if ( ! current_user_can( mmcpc_cap_manage() ) ) wp_die( esc_html__( 'Permesso negato.', 'membership-manager-passcreator' ) );
        $settings = mmcpc_settings();
        $cards = MMCPC_Card_Store::list_recent( 50 );
        $members = class_exists( 'MMC_API' ) ? MMC_API::list_members( array( 'limit' => 100 ) ) : array();
        $test = get_option( 'mmcpc_last_self_test', array() );
        ?>
        <div class="wrap mmcpc-admin">
            <h1><?php esc_html_e( 'Passcreator Add-on', 'membership-manager-passcreator' ); ?></h1>
            <?php self::notices(); ?>
            <div class="mmcpc-grid">
                <section class="mmcpc-card">
                    <h2><?php esc_html_e( 'Configurazione', 'membership-manager-passcreator' ); ?></h2>
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <input type="hidden" name="action" value="mmcpc_save_settings">
                        <?php wp_nonce_field( mmcpc_admin_nonce_action( 'save_settings' ) ); ?>
                        <table class="form-table" role="presentation">
                            <tr><th><label for="api_base">API Base</label></th><td><input class="regular-text" id="api_base" name="api_base" type="url" value="<?php echo esc_attr( $settings['api_base'] ); ?>"><p class="description">Solo HTTPS su passcreator.com o sottodomini.</p></td></tr>
                            <tr><th><label for="api_key">API key</label></th><td><input class="regular-text" id="api_key" name="api_key" type="password" value="" placeholder="<?php echo $settings['api_key'] ? esc_attr__( 'già salvata', 'membership-manager-passcreator' ) : ''; ?>"></td></tr>
                            <tr><th><label for="proxy_token">Proxy token</label></th><td><input class="regular-text" id="proxy_token" name="proxy_token" type="password" value="" placeholder="<?php echo $settings['proxy_token'] ? esc_attr__( 'già salvato', 'membership-manager-passcreator' ) : ''; ?>"><p class="description">Se presente, viene preferito all'API key.</p></td></tr>
                            <tr><th><label for="template_id">Template ID</label></th><td><input class="regular-text" id="template_id" name="template_id" type="text" value="<?php echo esc_attr( $settings['template_id'] ); ?>"></td></tr>
                            <tr><th>Emissione automatica</th><td><label><input type="checkbox" name="auto_issue" value="1" <?php checked( $settings['auto_issue'], '1' ); ?>> Crea/aggiorna la tessera quando un socio viene creato o aggiornato nel Core.</label></td></tr>
                            <tr><th>Push dopo emissione</th><td><label><input type="checkbox" name="push_on_issue" value="1" <?php checked( $settings['push_on_issue'], '1' ); ?>> Invia push dopo emissione/aggiornamento automatico.</label><br><input class="regular-text" name="push_text" type="text" value="<?php echo esc_attr( $settings['push_text'] ); ?>"></td></tr>
                        </table>
                        <h3><?php esc_html_e( 'Mapping campi template', 'membership-manager-passcreator' ); ?></h3>
                        <p class="description">Le key devono corrispondere esattamente ai campi del template Passcreator, consigliate minuscole.</p>
                        <div class="mmcpc-fields">
                            <label>Nome <input name="field_first_name" value="<?php echo esc_attr( $settings['field_first_name'] ); ?>"></label>
                            <label>Cognome <input name="field_last_name" value="<?php echo esc_attr( $settings['field_last_name'] ); ?>"></label>
                            <label>Email <input name="field_email" value="<?php echo esc_attr( $settings['field_email'] ); ?>"></label>
                            <label>Scadenza <input name="field_expiry" value="<?php echo esc_attr( $settings['field_expiry'] ); ?>"></label>
                            <label>Messaggio <input name="field_message" value="<?php echo esc_attr( $settings['field_message'] ); ?>"></label>
                            <label>Nome associazione <input name="field_organization_name" value="<?php echo esc_attr( $settings['field_organization_name'] ); ?>"></label>
                            <label>Tema <input name="field_theme_key" value="<?php echo esc_attr( $settings['field_theme_key'] ); ?>"></label>
                            <label>Colore primario <input name="field_primary_color" value="<?php echo esc_attr( $settings['field_primary_color'] ); ?>"></label>
                            <label>Colore secondario <input name="field_secondary_color" value="<?php echo esc_attr( $settings['field_secondary_color'] ); ?>"></label>
                            <label>Colore accento <input name="field_accent_color" value="<?php echo esc_attr( $settings['field_accent_color'] ); ?>"></label>
                            <label>Colore sfondo legacy <input name="field_bg_color" value="<?php echo esc_attr( $settings['field_bg_color'] ); ?>"></label>
                            <label>Colore testo legacy <input name="field_text_color" value="<?php echo esc_attr( $settings['field_text_color'] ); ?>"></label>
                        </div>
                        <p><label><input type="checkbox" name="enable_dynamic_images" value="1" <?php checked( $settings['enable_dynamic_images'], '1' ); ?>> Usa immagini dinamiche Passcreator (<code>urlToLogo</code>, <code>urlToBackground</code>, <code>urlToThumbnail</code>).</label></p>
                        <?php submit_button( __( 'Salva impostazioni', 'membership-manager-passcreator' ) ); ?>
                    </form>
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <input type="hidden" name="action" value="mmcpc_self_test">
                        <?php wp_nonce_field( mmcpc_admin_nonce_action( 'self_test' ) ); ?>
                        <?php submit_button( __( 'Esegui self-test Passcreator', 'membership-manager-passcreator' ), 'secondary' ); ?>
                    </form>
                    <?php self::render_self_test( $test ); ?>
                    <hr>
                    <h3><?php esc_html_e( 'Branding associazione', 'membership-manager-passcreator' ); ?></h3>
                    <p><?php esc_html_e( 'Dopo aver cambiato logo o colori nel Core, usa questo pulsante per aggiornare le tessere già create.', 'membership-manager-passcreator' ); ?></p>
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <input type="hidden" name="action" value="mmcpc_update_all_branding">
                        <?php wp_nonce_field( mmcpc_admin_nonce_action( 'update_all_branding' ) ); ?>
                        <?php submit_button( __( 'Aggiorna tutte le tessere con il branding corrente', 'membership-manager-passcreator' ), 'secondary' ); ?>
                    </form>
                </section>

                <section class="mmcpc-card">
                    <h2><?php esc_html_e( 'Emissione manuale', 'membership-manager-passcreator' ); ?></h2>
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <input type="hidden" name="action" value="mmcpc_issue_card">
                        <?php wp_nonce_field( mmcpc_admin_nonce_action( 'issue_card' ) ); ?>
                        <p><select name="member_id" required><?php foreach ( $members as $m ) : ?><option value="<?php echo esc_attr( $m['id'] ); ?>"><?php echo esc_html( trim( $m['first_name'] . ' ' . $m['last_name'] ) . ' <' . $m['email'] . '>' ); ?></option><?php endforeach; ?></select></p>
                        <?php submit_button( __( 'Crea/Aggiorna tessera', 'membership-manager-passcreator' ) ); ?>
                    </form>
                    <h3><?php esc_html_e( 'Push manuale', 'membership-manager-passcreator' ); ?></h3>
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <input type="hidden" name="action" value="mmcpc_push_card">
                        <?php wp_nonce_field( mmcpc_admin_nonce_action( 'push_card' ) ); ?>
                        <p><select name="member_id" required><?php foreach ( $members as $m ) : ?><option value="<?php echo esc_attr( $m['id'] ); ?>"><?php echo esc_html( trim( $m['first_name'] . ' ' . $m['last_name'] ) . ' <' . $m['email'] . '>' ); ?></option><?php endforeach; ?></select></p>
                        <p><input class="regular-text" name="message" type="text" value="<?php echo esc_attr( $settings['push_text'] ); ?>"></p>
                        <?php submit_button( __( 'Invia push', 'membership-manager-passcreator' ), 'secondary' ); ?>
                    </form>
                </section>
            </div>

            <h2><?php esc_html_e( 'Ultime tessere Passcreator', 'membership-manager-passcreator' ); ?></h2>
            <table class="widefat striped">
                <thead><tr><th>Socio</th><th>Email</th><th>Pass ID</th><th>Stato</th><th>Link</th><th>Errore</th><th>Aggiornato</th></tr></thead>
                <tbody>
                <?php if ( empty( $cards ) ) : ?><tr><td colspan="7">Nessuna tessera gestita dall'add-on.</td></tr><?php endif; ?>
                <?php foreach ( $cards as $card ) : ?>
                    <tr>
                        <td><?php echo esc_html( $card['member_id'] ); ?></td>
                        <td><?php echo esc_html( $card['email'] ); ?></td>
                        <td><code><?php echo esc_html( $card['pass_id'] ); ?></code></td>
                        <td><?php echo esc_html( $card['status'] ); ?></td>
                        <td><?php echo $card['public_url'] ? '<a href="' . esc_url( $card['public_url'] ) . '" target="_blank" rel="noopener">apri</a>' : ''; ?></td>
                        <td><?php echo esc_html( $card['last_error'] ); ?></td>
                        <td><?php echo esc_html( $card['updated_at'] ); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    private static function notices() {
        if ( isset( $_GET['mmcpc_saved'] ) ) echo '<div class="notice notice-success"><p>Impostazioni salvate.</p></div>';
        if ( isset( $_GET['mmcpc_tested'] ) ) echo '<div class="notice notice-info"><p>Self-test eseguito.</p></div>';
        if ( isset( $_GET['mmcpc_issued'] ) ) echo '<div class="notice notice-success"><p>Tessera creata/aggiornata.</p></div>';
        if ( isset( $_GET['mmcpc_pushed'] ) ) echo '<div class="notice notice-success"><p>Push inviato o già gestito da Passcreator.</p></div>';
        if ( isset( $_GET['mmcpc_error'] ) ) echo '<div class="notice notice-error"><p>' . esc_html( wp_unslash( $_GET['mmcpc_error'] ) ) . '</p></div>';
        if ( isset( $_GET['mmcpc_bulk_branding'] ) ) echo '<div class="notice notice-info"><p>' . esc_html( sprintf( 'Aggiornamento branding: %d ok, %d errori.', absint( $_GET['ok'] ?? 0 ), absint( $_GET['fail'] ?? 0 ) ) ) . '</p></div>';
    }

    private static function render_self_test( $test ) {
        if ( empty( $test ) || ! is_array( $test ) ) return;
        echo '<div class="mmcpc-test ' . ( ! empty( $test['ok'] ) ? 'ok' : 'bad' ) . '">';
        echo '<strong>Self-test: ' . ( ! empty( $test['ok'] ) ? 'OK' : 'KO' ) . '</strong><br>';
        if ( ! empty( $test['error'] ) ) echo '<p>' . esc_html( $test['error'] ) . '</p>';
        if ( ! empty( $test['api_root'] ) ) echo '<p>API root: <code>' . esc_html( $test['api_root'] ) . '</code></p>';
        if ( ! empty( $test['checks'] ) && is_array( $test['checks'] ) ) {
            echo '<ul>';
            foreach ( $test['checks'] as $name => $check ) {
                echo '<li><code>' . esc_html( $name ) . '</code>: ' . ( ! empty( $check['ok'] ) ? 'OK' : 'KO' );
                if ( ! empty( $check['code'] ) ) echo ' HTTP ' . esc_html( $check['code'] );
                if ( ! empty( $check['diagnostic'] ) ) echo ' — ' . esc_html( $check['diagnostic'] );
                echo '</li>';
            }
            echo '</ul>';
        }
        echo '</div>';
    }
}
