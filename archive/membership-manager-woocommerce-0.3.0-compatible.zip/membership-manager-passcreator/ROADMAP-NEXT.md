# Prossimo blocco consigliato

## Blocco 3 — Add-on WooCommerce separato

Obiettivo: spostare tutta la logica di vendita/rinnovo fuori dal Core.

Funzioni minime:

- rilevamento ordine completato;
- prodotto tessera configurabile;
- creazione/aggiornamento socio nel Core;
- rinnovo scadenza;
- compatibility layer HPOS;
- checkout prefill minimo;
- hook verso provider card, senza conoscere Passcreator direttamente.

## Note tecniche

Questo add-on Passcreator usa:

- `MMC_Card_Provider_Interface` del Core;
- hook `mmc_member_created` e `mmc_member_updated`;
- tabella separata `wp_mmc_passcreator_cards`;
- opzioni separate `mmcpc_settings`.

Non include WooCommerce e non deve essere pubblicato nel repository WordPress.org come parte del Core gratuito.
