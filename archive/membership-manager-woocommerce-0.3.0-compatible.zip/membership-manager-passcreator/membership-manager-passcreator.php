<?php
/**
 * Plugin Name: Membership Manager - Passcreator Add-on
 * Description: Add-on PRO separato per collegare Membership Manager Core a Passcreator. Richiede Membership Manager Core.
 * Version: 0.3.1
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Author: Membership Manager
 * Text Domain: membership-manager-passcreator
 * Domain Path: /languages
 * License: GPLv2 or later
 * Requires Plugins: membership-manager-core
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'MMCPC_VERSION', '0.3.1' );
define( 'MMCPC_FILE', __FILE__ );
define( 'MMCPC_PATH', plugin_dir_path( __FILE__ ) );
define( 'MMCPC_URL', plugin_dir_url( __FILE__ ) );
define( 'MMCPC_DB_VERSION', '0.1.0' );

require_once MMCPC_PATH . 'includes/helpers.php';
require_once MMCPC_PATH . 'includes/activator.php';
require_once MMCPC_PATH . 'includes/plugin.php';

register_activation_hook( __FILE__, array( 'MMCPC_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'MMCPC_Activator', 'deactivate' ) );

add_action( 'plugins_loaded', static function() {
    load_plugin_textdomain( 'membership-manager-passcreator', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
    MMCPC_Plugin::instance()->boot();
}, 20 );
