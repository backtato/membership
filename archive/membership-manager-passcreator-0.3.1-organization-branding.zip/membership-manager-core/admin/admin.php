<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MMC_Admin {
    public static function register() {
        add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
        add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
        add_action( 'admin_post_mmc_save_member', array( __CLASS__, 'save_member' ) );
        add_action( 'admin_post_mmc_save_organization_branding', array( 'MMC_Card_Profile_Service', 'handle_admin_save' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
    }

    public static function menu() {
        add_menu_page( __( 'Membership', 'membership-manager-core' ), __( 'Membership', 'membership-manager-core' ), mmc_cap_manage(), 'mmc-membership', array( __CLASS__, 'render_members' ), 'dashicons-groups', 56 );
        add_submenu_page( 'mmc-membership', __( 'Impostazioni', 'membership-manager-core' ), __( 'Impostazioni', 'membership-manager-core' ), mmc_cap_manage(), 'mmc-settings', array( __CLASS__, 'render_settings' ) );
    }

    public static function register_settings() {
        register_setting( 'mmc_settings', 'mmc_delete_data_on_uninstall', array( 'type' => 'boolean', 'sanitize_callback' => array( __CLASS__, 'sanitize_bool' ), 'default' => false ) );
        register_setting( 'mmc_settings', 'mmc_expiry_settings', array( 'type' => 'array', 'sanitize_callback' => array( 'MMC_Expiry_Engine', 'sanitize_settings' ), 'default' => MMC_Expiry_Engine::default_settings() ) );
    }

    public static function sanitize_bool( $value ) { return ! empty( $value ) ? 1 : 0; }

    public static function assets( $hook ) {
        if ( false === strpos( (string) $hook, 'mmc-' ) ) return;
        wp_enqueue_style( 'mmc-admin', MMC_URL . 'assets/css/admin.css', array(), MMC_VERSION );
        wp_enqueue_script( 'mmc-admin', MMC_URL . 'assets/js/admin.js', array(), MMC_VERSION, true );
    }

    public static function save_member() {
        if ( ! current_user_can( mmc_cap_manage() ) || ! mmc_verify_admin_nonce( 'mmc_save_member' ) ) wp_die( esc_html__( 'Permesso negato.', 'membership-manager-core' ) );
        $result = MMC_Member_Repository::upsert( array(
            'email' => isset( $_POST['email'] ) ? wp_unslash( $_POST['email'] ) : '',
            'first_name' => isset( $_POST['first_name'] ) ? wp_unslash( $_POST['first_name'] ) : '',
            'last_name' => isset( $_POST['last_name'] ) ? wp_unslash( $_POST['last_name'] ) : '',
            'expiry_date' => isset( $_POST['expiry_date'] ) ? wp_unslash( $_POST['expiry_date'] ) : '',
        ) );
        $url = add_query_arg( is_wp_error( $result ) ? 'mmc_error' : 'mmc_saved', '1', admin_url( 'admin.php?page=mmc-membership' ) );
        wp_safe_redirect( $url );
        exit;
    }

    public static function render_members() {
        if ( ! current_user_can( mmc_cap_manage() ) ) wp_die( esc_html__( 'Permesso negato.', 'membership-manager-core' ) );
        $members = MMC_Member_Repository::list_members( array( 'limit' => 100 ) );
        ?>
        <div class="wrap mmc-admin">
            <h1><?php esc_html_e( 'Membership Manager Core', 'membership-manager-core' ); ?></h1>
            <?php if ( isset( $_GET['mmc_saved'] ) ) : ?><div class="notice notice-success"><p><?php esc_html_e( 'Socio salvato.', 'membership-manager-core' ); ?></p></div><?php endif; ?>
            <?php if ( isset( $_GET['mmc_error'] ) ) : ?><div class="notice notice-error"><p><?php esc_html_e( 'Errore durante il salvataggio.', 'membership-manager-core' ); ?></p></div><?php endif; ?>
            <div class="mmc-grid">
                <section class="mmc-card"><h2><?php esc_html_e( 'Nuovo socio', 'membership-manager-core' ); ?></h2>
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <input type="hidden" name="action" value="mmc_save_member"><?php wp_nonce_field( 'mmc_save_member' ); ?>
                        <p><label><?php esc_html_e( 'Email', 'membership-manager-core' ); ?><br><input class="regular-text" type="email" name="email" required></label></p>
                        <p><label><?php esc_html_e( 'Nome', 'membership-manager-core' ); ?><br><input class="regular-text" type="text" name="first_name"></label></p>
                        <p><label><?php esc_html_e( 'Cognome', 'membership-manager-core' ); ?><br><input class="regular-text" type="text" name="last_name"></label></p>
                        <p><label><?php esc_html_e( 'Scadenza', 'membership-manager-core' ); ?><br><input type="date" name="expiry_date"></label></p>
                        <?php submit_button( __( 'Salva socio', 'membership-manager-core' ) ); ?>
                    </form>
                </section>
                <section class="mmc-card"><h2><?php esc_html_e( 'Export', 'membership-manager-core' ); ?></h2>
                    <p><?php esc_html_e( 'Esporta i primi 200 soci in CSV.', 'membership-manager-core' ); ?></p>
                    <a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mmc_export_members' ), 'mmc_export_members' ) ); ?>"><?php esc_html_e( 'Esporta CSV', 'membership-manager-core' ); ?></a>
                </section>
            </div>
            <h2><?php esc_html_e( 'Soci', 'membership-manager-core' ); ?></h2>
            <table class="widefat striped"><thead><tr><th><?php esc_html_e( 'Email', 'membership-manager-core' ); ?></th><th><?php esc_html_e( 'Nome', 'membership-manager-core' ); ?></th><th><?php esc_html_e( 'Cognome', 'membership-manager-core' ); ?></th><th><?php esc_html_e( 'Stato', 'membership-manager-core' ); ?></th><th><?php esc_html_e( 'Scadenza', 'membership-manager-core' ); ?></th></tr></thead><tbody>
            <?php if ( empty( $members ) ) : ?><tr><td colspan="5"><?php esc_html_e( 'Nessun socio.', 'membership-manager-core' ); ?></td></tr><?php else : foreach ( $members as $member ) : ?>
                <tr><td><?php echo esc_html( $member['email'] ); ?></td><td><?php echo esc_html( $member['first_name'] ); ?></td><td><?php echo esc_html( $member['last_name'] ); ?></td><td><?php echo esc_html( $member['status'] ); ?></td><td><?php echo esc_html( $member['expiry_date'] ); ?></td></tr>
            <?php endforeach; endif; ?></tbody></table>
        </div><?php
    }

    public static function render_settings() {
        if ( ! current_user_can( mmc_cap_manage() ) ) wp_die( esc_html__( 'Permesso negato.', 'membership-manager-core' ) );
        $expiry = mmc_get_expiry_settings();
        $brand = MMC_Card_Profile_Service::get_settings();
        $presets = MMC_Card_Profile_Service::presets();
        ?>
        <div class="wrap mmc-admin">
            <h1><?php esc_html_e( 'Impostazioni Membership Manager Core', 'membership-manager-core' ); ?></h1>
            <?php if ( isset( $_GET['mmc_branding_saved'] ) ) : ?><div class="notice notice-success"><p><?php esc_html_e( 'Branding associazione salvato.', 'membership-manager-core' ); ?></p></div><?php endif; ?>
            <?php if ( isset( $_GET['mmc_branding_error'] ) ) : ?><div class="notice notice-error"><p><?php echo esc_html( rawurldecode( wp_unslash( $_GET['mmc_branding_error'] ) ) ); ?></p></div><?php endif; ?>

            <form method="post" action="options.php">
                <?php settings_fields( 'mmc_settings' ); ?>
                <h2><?php esc_html_e( 'Scadenza e rinnovi', 'membership-manager-core' ); ?></h2>
                <table class="form-table" role="presentation">
                    <tr><th><label for="mmc_expiry_mode"><?php esc_html_e( 'Modalità scadenza', 'membership-manager-core' ); ?></label></th><td><select name="mmc_expiry_settings[expiry_mode]" id="mmc_expiry_mode"><option value="rolling_12_months" <?php selected( $expiry['expiry_mode'], 'rolling_12_months' ); ?>><?php esc_html_e( '12 mesi / durata mobile', 'membership-manager-core' ); ?></option><option value="fixed_year_end" <?php selected( $expiry['expiry_mode'], 'fixed_year_end' ); ?>><?php esc_html_e( 'Fino alla fine dell’anno', 'membership-manager-core' ); ?></option><option value="fixed_date" <?php selected( $expiry['expiry_mode'], 'fixed_date' ); ?>><?php esc_html_e( 'Data fissa', 'membership-manager-core' ); ?></option></select></td></tr>
                    <tr><th><label for="mmc_rolling_months"><?php esc_html_e( 'Durata mobile', 'membership-manager-core' ); ?></label></th><td><input name="mmc_expiry_settings[rolling_months]" id="mmc_rolling_months" type="number" min="1" max="120" value="<?php echo esc_attr( $expiry['rolling_months'] ); ?>" class="small-text"> <?php esc_html_e( 'mesi', 'membership-manager-core' ); ?></td></tr>
                    <tr><th><?php esc_html_e( 'Estensione rinnovo', 'membership-manager-core' ); ?></th><td><label><input type="checkbox" name="mmc_expiry_settings[extend_from_existing]" value="yes" <?php checked( $expiry['extend_from_existing'], 'yes' ); ?>> <?php esc_html_e( 'Se il socio è ancora attivo, estendi dalla scadenza esistente.', 'membership-manager-core' ); ?></label></td></tr>
                    <tr><th><?php esc_html_e( 'Fine anno', 'membership-manager-core' ); ?></th><td><input name="mmc_expiry_settings[fixed_year_day]" type="number" min="1" max="31" value="<?php echo esc_attr( $expiry['fixed_year_day'] ); ?>" class="small-text"> / <input name="mmc_expiry_settings[fixed_year_month]" type="number" min="1" max="12" value="<?php echo esc_attr( $expiry['fixed_year_month'] ); ?>" class="small-text"><br><label><input type="checkbox" name="mmc_expiry_settings[late_renewal_next_year]" value="yes" <?php checked( $expiry['late_renewal_next_year'], 'yes' ); ?>> <?php esc_html_e( 'Da questo mese assegna direttamente l’anno successivo:', 'membership-manager-core' ); ?></label> <input name="mmc_expiry_settings[late_renewal_month]" type="number" min="1" max="12" value="<?php echo esc_attr( $expiry['late_renewal_month'] ); ?>" class="small-text"></td></tr>
                    <tr><th><label for="mmc_fixed_date"><?php esc_html_e( 'Data fissa', 'membership-manager-core' ); ?></label></th><td><input name="mmc_expiry_settings[fixed_date]" id="mmc_fixed_date" type="date" value="<?php echo esc_attr( $expiry['fixed_date'] ); ?>"></td></tr>
                    <tr><th><label for="mmc_renew_link_ttl_days"><?php esc_html_e( 'Validità link rinnovo', 'membership-manager-core' ); ?></label></th><td><input name="mmc_expiry_settings[renew_link_ttl_days]" id="mmc_renew_link_ttl_days" type="number" min="1" max="90" value="<?php echo esc_attr( $expiry['renew_link_ttl_days'] ); ?>" class="small-text"> <?php esc_html_e( 'giorni', 'membership-manager-core' ); ?></td></tr>
                    <tr><th><?php esc_html_e( 'Parametri URL rinnovo', 'membership-manager-core' ); ?></th><td><input name="mmc_expiry_settings[renew_email_param]" type="text" value="<?php echo esc_attr( $expiry['renew_email_param'] ); ?>" class="regular-text"><br><input name="mmc_expiry_settings[renew_ts_param]" type="text" value="<?php echo esc_attr( $expiry['renew_ts_param'] ); ?>" class="regular-text"><br><input name="mmc_expiry_settings[renew_sig_param]" type="text" value="<?php echo esc_attr( $expiry['renew_sig_param'] ); ?>" class="regular-text"></td></tr>
                </table>
                <h2><?php esc_html_e( 'Dati', 'membership-manager-core' ); ?></h2>
                <table class="form-table" role="presentation"><tr><th><?php esc_html_e( 'Disinstallazione', 'membership-manager-core' ); ?></th><td><label><input type="checkbox" name="mmc_delete_data_on_uninstall" value="1" <?php checked( get_option( 'mmc_delete_data_on_uninstall', false ) ); ?>> <?php esc_html_e( 'Elimina tabelle e opzioni del Core alla disinstallazione.', 'membership-manager-core' ); ?></label></td></tr></table>
                <?php submit_button( __( 'Salva impostazioni Core', 'membership-manager-core' ) ); ?>
            </form>

            <hr>
            <h2><?php esc_html_e( 'Branding associazione/team', 'membership-manager-core' ); ?></h2>
            <p><?php esc_html_e( 'Queste impostazioni valgono per tutti i soci e per tutte le tessere generate da questo sito/plugin installato.', 'membership-manager-core' ); ?></p>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
                <input type="hidden" name="action" value="mmc_save_organization_branding"><?php wp_nonce_field( 'mmc_save_organization_branding' ); ?>
                <table class="form-table" role="presentation">
                    <tr><th><?php esc_html_e( 'Attivo', 'membership-manager-core' ); ?></th><td><input type="hidden" name="mmc_organization_branding_settings[enabled]" value="no"><label><input type="checkbox" name="mmc_organization_branding_settings[enabled]" value="yes" <?php checked( $brand['enabled'], 'yes' ); ?>> <?php esc_html_e( 'Invia il branding dell’associazione alle tessere.', 'membership-manager-core' ); ?></label></td></tr>
                    <tr><th><label for="mmc_org_name"><?php esc_html_e( 'Nome associazione/team', 'membership-manager-core' ); ?></label></th><td><input id="mmc_org_name" name="mmc_organization_branding_settings[organization_name]" type="text" class="regular-text" value="<?php echo esc_attr( $brand['organization_name'] ); ?>"></td></tr>
                    <tr><th><?php esc_html_e( 'Tema preset', 'membership-manager-core' ); ?></th><td><select name="mmc_organization_branding_settings[theme_key]"><?php foreach ( $presets as $key => $preset ) : ?><option value="<?php echo esc_attr( $key ); ?>" <?php selected( $brand['theme_key'], $key ); ?>><?php echo esc_html( $preset['label'] ); ?></option><?php endforeach; ?></select></td></tr>
                    <tr><th><?php esc_html_e( 'Colori', 'membership-manager-core' ); ?></th><td><label><?php esc_html_e( 'Primario', 'membership-manager-core' ); ?> <input type="color" name="mmc_organization_branding_settings[primary_color]" value="<?php echo esc_attr( $brand['primary_color'] ); ?>"></label> <label><?php esc_html_e( 'Secondario', 'membership-manager-core' ); ?> <input type="color" name="mmc_organization_branding_settings[secondary_color]" value="<?php echo esc_attr( $brand['secondary_color'] ); ?>"></label> <label><?php esc_html_e( 'Accento', 'membership-manager-core' ); ?> <input type="color" name="mmc_organization_branding_settings[accent_color]" value="<?php echo esc_attr( $brand['accent_color'] ); ?>"></label></td></tr>
                    <tr><th><?php esc_html_e( 'Logo', 'membership-manager-core' ); ?></th><td><input type="file" name="mmc_brand_logo" accept="image/jpeg,image/png,image/webp"> <?php if ( $brand['logo_url'] ) : ?><a href="<?php echo esc_url( $brand['logo_url'] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'logo attuale', 'membership-manager-core' ); ?></a><?php endif; ?><input type="hidden" name="mmc_organization_branding_settings[logo_url]" value="<?php echo esc_attr( $brand['logo_url'] ); ?>"><input type="hidden" name="mmc_organization_branding_settings[logo_attachment_id]" value="<?php echo esc_attr( $brand['logo_attachment_id'] ); ?>"></td></tr>
                    <tr><th><?php esc_html_e( 'Sfondo tessera', 'membership-manager-core' ); ?></th><td><input type="file" name="mmc_brand_background" accept="image/jpeg,image/png,image/webp"> <?php if ( $brand['background_url'] ) : ?><a href="<?php echo esc_url( $brand['background_url'] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'sfondo attuale', 'membership-manager-core' ); ?></a><?php endif; ?><input type="hidden" name="mmc_organization_branding_settings[background_url]" value="<?php echo esc_attr( $brand['background_url'] ); ?>"><input type="hidden" name="mmc_organization_branding_settings[background_attachment_id]" value="<?php echo esc_attr( $brand['background_attachment_id'] ); ?>"></td></tr>
                    <tr><th><?php esc_html_e( 'Thumbnail/Icona', 'membership-manager-core' ); ?></th><td><input type="file" name="mmc_brand_thumbnail" accept="image/jpeg,image/png,image/webp"> <?php if ( $brand['thumbnail_url'] ) : ?><a href="<?php echo esc_url( $brand['thumbnail_url'] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'thumbnail attuale', 'membership-manager-core' ); ?></a><?php endif; ?><input type="hidden" name="mmc_organization_branding_settings[thumbnail_url]" value="<?php echo esc_attr( $brand['thumbnail_url'] ); ?>"><input type="hidden" name="mmc_organization_branding_settings[thumbnail_attachment_id]" value="<?php echo esc_attr( $brand['thumbnail_attachment_id'] ); ?>"></td></tr>
                    <tr><th><label for="mmc_brand_presets"><?php esc_html_e( 'Preset colori', 'membership-manager-core' ); ?></label></th><td><textarea id="mmc_brand_presets" name="mmc_organization_branding_settings[presets_raw]" rows="6" class="large-text code"><?php echo esc_textarea( $brand['presets_raw'] ); ?></textarea><p class="description"><?php esc_html_e( 'Formato: key|Etichetta|colore_primario|colore_secondario|colore_accento', 'membership-manager-core' ); ?></p></td></tr>
                    <tr><th><?php esc_html_e( 'Upload', 'membership-manager-core' ); ?></th><td><input type="number" min="1" max="10" name="mmc_organization_branding_settings[max_upload_mb]" value="<?php echo esc_attr( $brand['max_upload_mb'] ); ?>" class="small-text"> MB</td></tr>
                </table>
                <?php submit_button( __( 'Salva branding associazione', 'membership-manager-core' ) ); ?>
            </form>
        </div><?php
    }
}
