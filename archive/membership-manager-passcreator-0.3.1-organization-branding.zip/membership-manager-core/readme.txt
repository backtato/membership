=== Membership Manager Core ===
Contributors: membership-manager
Tags: membership, members, association, events, qr-code
Requires at least: 6.2
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 0.4.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A lightweight membership core for associations: members, expiry dates, events, member portal, QR check-ins and organization branding.

== Description ==

Membership Manager Core provides a neutral, extensible foundation for associations, clubs and small organizations that need to manage members, expiry dates, events and QR check-ins inside WordPress.

The plugin is intentionally independent from paid external services. It does not require WooCommerce, Passcreator, wallet providers, mailing services or third-party APIs to work.

Core features:

* Basic member records
* Membership status and expiry date
* Configurable expiry engine: rolling months, fixed year-end or fixed date
* Secure signed renewal-link engine for commerce add-ons
* Organization/team-level branding: name, colors, logo, background and thumbnail
* Admin member list
* CSV export
* Event custom post type
* Next event shortcode
* Logged-in member portal shortcode
* Authenticated REST check-in endpoint
* Duplicate check-in guard
* Privacy exporter and eraser
* Optional data deletion on uninstall

Shortcodes:

* `[membership_portal]`
* `[membership_next_event]`

Developer hooks include `mmc_core_loaded`, `mmc_member_created`, `mmc_member_updated`, `mmc_member_checked_in`, `mmc_organization_branding_updated`, `mmc_register_event_cpt`, `mmc_cap_manage`, and `mmc_checkin_duplicate_window_seconds`.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/` or install it from the WordPress admin.
2. Activate the plugin.
3. Open the "Membership" menu in the WordPress admin.
4. Add your first member.
5. Configure organization branding under Membership > Settings.
6. Add `[membership_portal]` to a private page if you want members to see their profile.
7. Add `[membership_next_event]` to show the next future event.

== Frequently Asked Questions ==

= Is branding per member or per association? =

Branding is per WordPress installation/customer. One association or team sets its own logo and colors, and those values are applied to all cards generated for its members.

= Does this plugin require WooCommerce? =

No. WooCommerce support should live in a separate add-on.

= Does this plugin require Passcreator or another wallet provider? =

No. The core plugin does not call external wallet APIs. Digital card providers should be implemented as separate add-ons.

= Does the plugin send personal data to external services? =

No. The core plugin stores membership data locally in your WordPress database and does not send it to external services by itself.

== Privacy ==

Membership Manager Core stores membership records such as email address, first name, last name, membership status and expiry date. It also stores event check-in records. Organization branding settings may store uploaded logo/background/thumbnail URLs in WordPress media.

The plugin integrates with the WordPress personal data exporter and eraser tools.

== Changelog ==

= 0.4.1 =
* Reworked card customization from per-member profiles to organization/team-level branding.
* Added public API for organization branding pass fields.
* Removed member-facing card customization form.

= 0.4.0 =
* Introduced first card customization draft.

= 0.3.0 =
* Added Core expiry engine with rolling 12-month, fixed year-end and fixed-date modes.
* Added signed renewal URLs with timestamp and HMAC signature.
* Exposed expiry/renewal methods through the public add-on API.

= 0.1.1 =
* Added settings page with explicit uninstall data deletion option.
* Expanded WordPress.org readme.
* Added privacy policy helper content.
* Added duplicate check-in guard.

= 0.1.0 =
* Initial separated Core draft.
