<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MMC_Shortcodes {
    public static function register() {
        add_shortcode( 'membership_portal', array( __CLASS__, 'portal' ) );
        add_shortcode( 'membership_next_event', array( __CLASS__, 'next_event' ) );
    }

    public static function portal() {
        if ( ! is_user_logged_in() ) {
            return '<p>' . esc_html__( 'Accedi per visualizzare il tuo profilo socio.', 'membership-manager-core' ) . '</p>';
        }

        $user = wp_get_current_user();
        $member = MMC_Member_Repository::get_by_email( $user->user_email );
        if ( ! $member ) {
            return '<p>' . esc_html__( 'Nessun profilo socio associato a questo account.', 'membership-manager-core' ) . '</p>';
        }

        ob_start();
        ?>
        <div class="mmc-portal">
            <h2><?php esc_html_e( 'Profilo socio', 'membership-manager-core' ); ?></h2>
            <p><strong><?php esc_html_e( 'Nome', 'membership-manager-core' ); ?>:</strong> <?php echo esc_html( trim( $member['first_name'] . ' ' . $member['last_name'] ) ); ?></p>
            <p><strong><?php esc_html_e( 'Stato', 'membership-manager-core' ); ?>:</strong> <?php echo esc_html( $member['status'] ); ?></p>
            <p><strong><?php esc_html_e( 'Scadenza', 'membership-manager-core' ); ?>:</strong> <?php echo esc_html( $member['expiry_date'] ); ?></p>
            <?php echo wp_kses_post( apply_filters( 'mmc_member_portal_extra_html', '', $member ) ); ?>
            <?php do_action( 'mmc_portal_after_member_card', $member ); ?>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function next_event() {
        $event = MMC_Events_Service::get_next_event();
        if ( ! $event ) {
            return '<p>' . esc_html__( 'Nessun evento futuro disponibile.', 'membership-manager-core' ) . '</p>';
        }

        $date = ! empty( $event['start_ts'] ) ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $event['start_ts'] ) : '';
        return sprintf(
            '<div class="mmc-next-event"><strong>%s</strong><br><span>%s</span><br><a href="%s">%s</a></div>',
            esc_html( $event['title'] ),
            esc_html( $date ),
            esc_url( $event['url'] ),
            esc_html__( 'Apri evento', 'membership-manager-core' )
        );
    }
}
