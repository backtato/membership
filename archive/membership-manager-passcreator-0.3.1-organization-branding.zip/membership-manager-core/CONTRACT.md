# Membership Manager Core — Public Add-on Contract

Versione contratto: `1.2.0`  
Core minimo richiesto per gli add-on nuovi: `0.4.1`

Gli add-on devono usare questa API pubblica, evitando dipendenze dirette da repository o servizi interni.

## API pubblica stabile

- `MMC_API::contract_version()` / `mmc_api_contract_version()`
- `MMC_API::core_version()`
- `MMC_API::manage_capability()`
- `MMC_API::get_member($member_id)` / `mmc_get_member($member_id)`
- `MMC_API::get_member_by_email($email)` / `mmc_get_member_by_email($email)`
- `MMC_API::upsert_member(array $data)` / `mmc_upsert_member(array $data)`
- `MMC_API::list_members(array $args = [])` / `mmc_list_members(array $args = [])`
- `MMC_API::record_checkin(array $data)` / `mmc_record_checkin(array $data)`
- `MMC_API::get_next_event()` / `mmc_get_next_event()`
- `MMC_API::get_card_provider()` / `mmc_get_card_provider()`
- `MMC_API::get_member_card_url($member)` / `mmc_get_member_card_url($member)`
- `MMC_API::get_expiry_settings()` / `mmc_api_get_expiry_settings()`
- `MMC_API::compute_expiry_date($current_expiry, array $context = [])` / `mmc_compute_expiry_date()`
- `MMC_API::generate_renew_url($email, $base_url = '', array $args = [])` / `mmc_generate_renew_url()`
- `MMC_API::validate_renew_request($source = null, array $args = [])` / `mmc_validate_renew_request()`
- `MMC_API::get_organization_branding()` / `mmc_api_get_organization_branding()`
- `MMC_API::get_organization_branding_pass_fields()` / `mmc_api_get_organization_branding_pass_fields()`

## Hook pubblici

### Azioni

- `mmc_contract_loaded` — fired quando il contratto pubblico è disponibile. Argomento: contract version.
- `mmc_core_loaded` — fired dopo il bootstrap completo del Core.
- `mmc_member_created` — argomenti: member_id, payload.
- `mmc_member_updated` — argomenti: member_id, payload.
- `mmc_member_checked_in` — argomenti: checkin_id, payload.
- `mmc_portal_after_member_card` — argomento: member array.
- `mmc_membership_activated` — hook di dominio usabile dagli add-on commerce.
- `mmc_organization_branding_updated` — argomenti: new_branding, old_settings.

### Filtri

- `mmc_cap_manage`
- `mmc_card_provider`
- `mmc_member_card_url`
- `mmc_register_event_cpt`
- `mmc_checkin_duplicate_window_seconds`
- `mmc_organization_branding`
- `mmc_organization_branding_pass_fields`

## Organization branding

La personalizzazione grafica è a livello associazione/team, non a livello singolo socio.

Campi standard:

- `organization_name`
- `theme_key`
- `primary_color`
- `secondary_color`
- `accent_color`
- `logo_url`
- `background_url`
- `thumbnail_url`

I provider wallet devono leggere i campi via `MMC_API::get_organization_branding_pass_fields()`.

## Expiry engine

La scadenza è responsabilità del Core, non degli add-on commerce. Modalità supportate:

- `rolling_12_months`
- `fixed_year_end`
- `fixed_date`

## Renewal link firmati

Il link di rinnovo deve contenere almeno:

- `mmc_renew_email`
- `mmc_renew_ts`
- `mmc_renew_sig`

La firma è HMAC SHA-256 su `email|timestamp` con salt WordPress.
