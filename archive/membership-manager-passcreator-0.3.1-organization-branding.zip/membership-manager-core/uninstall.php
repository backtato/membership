<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) exit;

$delete_data = get_option( 'mmc_delete_data_on_uninstall', false );
if ( $delete_data ) {
    global $wpdb;

    $tables = array(
        $wpdb->prefix . 'mmc_members',
        $wpdb->prefix . 'mmc_checkins',
        // Legacy from 0.4.0 per-member customization draft. Kept here only for cleanup.
        $wpdb->prefix . 'mmc_card_profiles',
    );

    foreach ( $tables as $table ) {
        $wpdb->query( 'DROP TABLE IF EXISTS `' . esc_sql( $table ) . '`' );
    }

    delete_option( 'mmc_db_version' );
    delete_option( 'mmc_installed_at' );
    delete_option( 'mmc_delete_data_on_uninstall' );
    delete_option( 'mmc_expiry_settings' );
    delete_option( 'mmc_organization_branding_settings' );
    delete_option( 'mmc_card_customization_settings' );
}
