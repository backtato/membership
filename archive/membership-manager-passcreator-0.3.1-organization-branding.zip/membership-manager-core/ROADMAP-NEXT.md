# Next roadmap after Core 0.1.1

## Recommended next block: Integration contract stabilization

Before expanding commercial add-ons, stabilize the contract between Core and add-ons.

### Goals

1. Define a formal registry for card providers.
2. Define service-level APIs for member lifecycle events.
3. Define admin notices when an add-on depends on Core but Core is missing or outdated.
4. Add a small developer documentation file with supported hooks and payload shapes.
5. Add unit/integration test scaffolding.

### Why this is the correct next step

The Passcreator and WooCommerce add-ons must not call random Core internals. If the contract is stabilized now, future refactors will not break paid add-ons.

### Proposed version target

Core 0.2.0 should focus on add-on API stability, not new end-user features.
