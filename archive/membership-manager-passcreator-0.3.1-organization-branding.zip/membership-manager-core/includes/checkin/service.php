<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MMC_Checkin_Service {
    public static function register_rest_routes() {
        register_rest_route( 'mmc/v1', '/checkin', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'rest_checkin' ),
            'permission_callback' => array( __CLASS__, 'can_checkin' ),
            'args'                => array(
                'email'       => array( 'required' => true, 'type' => 'string' ),
                'event_id'    => array( 'required' => false, 'type' => 'string' ),
                'event_label' => array( 'required' => false, 'type' => 'string' ),
            ),
        ) );
    }

    public static function can_checkin() {
        return current_user_can( mmc_cap_manage() );
    }

    public static function rest_checkin( WP_REST_Request $request ) {
        $email = mmc_clean_email( $request->get_param( 'email' ) );
        if ( ! is_email( $email ) ) {
            return new WP_Error( 'mmc_invalid_email', __( 'Email non valida.', 'membership-manager-core' ), array( 'status' => 400 ) );
        }

        $member = MMC_Member_Repository::get_by_email( $email );
        $result = self::record( array(
            'email'       => $email,
            'member_id'   => $member ? absint( $member['id'] ) : null,
            'event_id'    => sanitize_text_field( (string) $request->get_param( 'event_id' ) ),
            'event_label' => sanitize_text_field( (string) $request->get_param( 'event_label' ) ),
            'source'      => 'rest',
        ) );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( array(
            'ok'        => true,
            'checkin_id'=> $result,
            'member'    => $member,
        ) );
    }

    public static function record( array $data ) {
        global $wpdb;
        $email = isset( $data['email'] ) ? mmc_clean_email( $data['email'] ) : '';
        if ( ! is_email( $email ) ) {
            return new WP_Error( 'mmc_invalid_email', __( 'Email non valida.', 'membership-manager-core' ) );
        }

        $event_id = isset( $data['event_id'] ) ? sanitize_text_field( $data['event_id'] ) : '';
        if ( self::is_duplicate_recent_checkin( $email, $event_id ) ) {
            return new WP_Error( 'mmc_duplicate_checkin', __( 'Check-in già registrato di recente.', 'membership-manager-core' ) );
        }

        $payload = array(
            'member_id'     => ! empty( $data['member_id'] ) ? absint( $data['member_id'] ) : null,
            'email'         => $email,
            'event_id'      => $event_id,
            'event_label'   => isset( $data['event_label'] ) ? sanitize_text_field( $data['event_label'] ) : '',
            'source'        => isset( $data['source'] ) ? sanitize_key( $data['source'] ) : 'manual',
            'checked_in_at' => current_time( 'mysql' ),
            'created_by'    => get_current_user_id() ?: null,
            'context'       => ! empty( $data['context'] ) ? wp_json_encode( $data['context'] ) : null,
        );

        $inserted = $wpdb->insert( mmc_table_checkins(), $payload );
        if ( ! $inserted ) {
            return new WP_Error( 'mmc_checkin_failed', __( 'Check-in non riuscito.', 'membership-manager-core' ) );
        }

        $id = absint( $wpdb->insert_id );
        do_action( 'mmc_member_checked_in', $id, $payload );
        return $id;
    }

    private static function is_duplicate_recent_checkin( $email, $event_id ) {
        global $wpdb;
        $window_seconds = absint( apply_filters( 'mmc_checkin_duplicate_window_seconds', 30 ) );
        if ( ! $window_seconds ) {
            return false;
        }

        $since = gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - $window_seconds );
        $count = (int) $wpdb->get_var( $wpdb->prepare(
            'SELECT COUNT(*) FROM ' . mmc_table_checkins() . ' WHERE email = %s AND event_id = %s AND checked_in_at >= %s',
            $email,
            $event_id,
            $since
        ) );

        return $count > 0;
    }
}
