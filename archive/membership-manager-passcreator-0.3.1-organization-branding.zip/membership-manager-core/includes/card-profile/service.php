<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Organization/team-level branding for all membership cards.
 *
 * This replaces the previous per-member customization model. One WordPress
 * installation/customer = one brand identity applied to every card.
 */
class MMC_Card_Profile_Service {
    public static function default_settings() {
        return array(
            'enabled' => 'yes',
            'organization_name' => get_bloginfo( 'name' ),
            'theme_key' => 'standard',
            'primary_color' => '#111827',
            'secondary_color' => '#ffffff',
            'accent_color' => '#c8102e',
            'logo_url' => '',
            'background_url' => '',
            'thumbnail_url' => '',
            'logo_attachment_id' => 0,
            'background_attachment_id' => 0,
            'thumbnail_attachment_id' => 0,
            'allowed_mime_types' => array( 'image/jpeg', 'image/png', 'image/webp' ),
            'max_upload_mb' => 3,
            'presets_raw' => self::default_presets_raw(),
        );
    }

    public static function default_presets_raw() {
        return "standard|Standard|#111827|#ffffff|#c8102e\nrosso|Rosso|#c8102e|#ffffff|#111827\nnero|Nero|#000000|#ffffff|#c8102e\noro|Oro|#b8860b|#111827|#ffffff";
    }

    public static function get_settings() {
        $settings = get_option( 'mmc_organization_branding_settings', array() );
        if ( ! is_array( $settings ) ) $settings = array();

        // Backward compatibility: migrate old per-member customization settings if present.
        $old = get_option( 'mmc_card_customization_settings', array() );
        if ( empty( $settings ) && is_array( $old ) && ! empty( $old ) ) {
            $settings = array(
                'enabled' => isset( $old['enabled'] ) ? $old['enabled'] : 'yes',
                'presets_raw' => isset( $old['presets_raw'] ) ? $old['presets_raw'] : self::default_presets_raw(),
                'max_upload_mb' => isset( $old['max_upload_mb'] ) ? $old['max_upload_mb'] : 3,
            );
        }

        return self::sanitize_settings( wp_parse_args( $settings, self::default_settings() ) );
    }

    public static function sanitize_settings( $settings ) {
        $settings = is_array( $settings ) ? $settings : array();
        $defaults = self::default_settings();
        $settings = wp_parse_args( $settings, $defaults );
        $settings['enabled'] = ! empty( $settings['enabled'] ) && 'no' !== $settings['enabled'] ? 'yes' : 'no';
        $settings['organization_name'] = sanitize_text_field( $settings['organization_name'] );
        $settings['theme_key'] = sanitize_key( $settings['theme_key'] );
        $settings['primary_color'] = self::sanitize_hex_color( $settings['primary_color'] ) ?: $defaults['primary_color'];
        $settings['secondary_color'] = self::sanitize_hex_color( $settings['secondary_color'] ) ?: $defaults['secondary_color'];
        $settings['accent_color'] = self::sanitize_hex_color( $settings['accent_color'] ) ?: $defaults['accent_color'];
        $settings['logo_url'] = esc_url_raw( $settings['logo_url'] );
        $settings['background_url'] = esc_url_raw( $settings['background_url'] );
        $settings['thumbnail_url'] = esc_url_raw( $settings['thumbnail_url'] );
        $settings['logo_attachment_id'] = absint( $settings['logo_attachment_id'] );
        $settings['background_attachment_id'] = absint( $settings['background_attachment_id'] );
        $settings['thumbnail_attachment_id'] = absint( $settings['thumbnail_attachment_id'] );
        $settings['max_upload_mb'] = max( 1, min( 10, absint( $settings['max_upload_mb'] ) ) );
        $settings['presets_raw'] = isset( $settings['presets_raw'] ) ? sanitize_textarea_field( (string) $settings['presets_raw'] ) : $defaults['presets_raw'];
        $mimes = isset( $settings['allowed_mime_types'] ) && is_array( $settings['allowed_mime_types'] ) ? $settings['allowed_mime_types'] : $defaults['allowed_mime_types'];
        $allowed = array( 'image/jpeg', 'image/png', 'image/webp' );
        $settings['allowed_mime_types'] = array_values( array_intersect( array_map( 'sanitize_text_field', $mimes ), $allowed ) );
        if ( empty( $settings['allowed_mime_types'] ) ) $settings['allowed_mime_types'] = $defaults['allowed_mime_types'];
        return $settings;
    }

    public static function presets() {
        $settings = self::get_settings();
        $rows = preg_split( '/\r\n|\r|\n/', (string) $settings['presets_raw'] );
        $out = array();
        foreach ( $rows as $row ) {
            $row = trim( $row );
            if ( '' === $row || 0 === strpos( $row, '#' ) ) continue;
            $parts = array_map( 'trim', explode( '|', $row ) );
            $key = sanitize_key( $parts[0] ?? '' );
            if ( '' === $key ) continue;
            $out[ $key ] = array(
                'key' => $key,
                'label' => sanitize_text_field( $parts[1] ?? $key ),
                'primary_color' => self::sanitize_hex_color( $parts[2] ?? '' ),
                'secondary_color' => self::sanitize_hex_color( $parts[3] ?? '' ),
                'accent_color' => self::sanitize_hex_color( $parts[4] ?? '' ),
            );
        }
        return apply_filters( 'mmc_organization_branding_presets', $out );
    }

    public static function sanitize_hex_color( $value ) {
        $value = trim( (string) $value );
        if ( '' === $value ) return '';
        if ( function_exists( 'sanitize_hex_color' ) ) {
            $san = sanitize_hex_color( $value );
            return $san ? $san : '';
        }
        return preg_match( '/^#[0-9a-fA-F]{6}$/', $value ) ? strtolower( $value ) : '';
    }

    public static function get_branding() {
        $settings = self::get_settings();
        $presets = self::presets();
        if ( ! empty( $settings['theme_key'] ) && isset( $presets[ $settings['theme_key'] ] ) ) {
            $preset = $presets[ $settings['theme_key'] ];
            foreach ( array( 'primary_color', 'secondary_color', 'accent_color' ) as $key ) {
                if ( empty( $settings[ $key ] ) && ! empty( $preset[ $key ] ) ) {
                    $settings[ $key ] = $preset[ $key ];
                }
            }
        }

        $branding = array(
            'enabled' => $settings['enabled'],
            'organization_name' => $settings['organization_name'],
            'theme_key' => $settings['theme_key'],
            'primary_color' => $settings['primary_color'],
            'secondary_color' => $settings['secondary_color'],
            'accent_color' => $settings['accent_color'],
            'logo_url' => $settings['logo_url'],
            'background_url' => $settings['background_url'],
            'thumbnail_url' => $settings['thumbnail_url'],
            'logo_attachment_id' => absint( $settings['logo_attachment_id'] ),
            'background_attachment_id' => absint( $settings['background_attachment_id'] ),
            'thumbnail_attachment_id' => absint( $settings['thumbnail_attachment_id'] ),
        );

        return apply_filters( 'mmc_organization_branding', $branding );
    }

    public static function get_pass_fields() {
        $b = self::get_branding();
        if ( 'yes' !== $b['enabled'] ) {
            return array();
        }
        $fields = array(
            'organization_name' => $b['organization_name'],
            'theme_key' => $b['theme_key'],
            'brand_color' => $b['primary_color'],
            'primary_color' => $b['primary_color'],
            'secondary_color' => $b['secondary_color'],
            'accent_color' => $b['accent_color'],
        );
        if ( ! empty( $b['logo_url'] ) ) $fields['urlToLogo'] = esc_url_raw( $b['logo_url'] );
        if ( ! empty( $b['background_url'] ) ) $fields['urlToBackground'] = esc_url_raw( $b['background_url'] );
        if ( ! empty( $b['thumbnail_url'] ) ) $fields['urlToThumbnail'] = esc_url_raw( $b['thumbnail_url'] );
        return apply_filters( 'mmc_organization_branding_pass_fields', $fields, $b );
    }

    public static function handle_admin_save() {
        if ( ! current_user_can( mmc_cap_manage() ) || empty( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'mmc_save_organization_branding' ) ) {
            wp_die( esc_html__( 'Permesso negato.', 'membership-manager-core' ) );
        }

        $old = self::get_settings();
        $data = isset( $_POST['mmc_organization_branding_settings'] ) && is_array( $_POST['mmc_organization_branding_settings'] ) ? wp_unslash( $_POST['mmc_organization_branding_settings'] ) : array();
        $settings = self::sanitize_settings( wp_parse_args( $data, $old ) );

        foreach ( array( 'logo' => 'logo', 'background' => 'background', 'thumbnail' => 'thumbnail' ) as $field => $prefix ) {
            $uploaded = self::handle_upload( 'mmc_brand_' . $field );
            if ( is_wp_error( $uploaded ) ) {
                wp_safe_redirect( add_query_arg( 'mmc_branding_error', rawurlencode( $uploaded->get_error_message() ), admin_url( 'admin.php?page=mmc-settings' ) ) );
                exit;
            }
            if ( is_array( $uploaded ) ) {
                $settings[ $prefix . '_url' ] = $uploaded['url'];
                $settings[ $prefix . '_attachment_id' ] = $uploaded['id'];
            }
        }

        update_option( 'mmc_organization_branding_settings', $settings, false );
        do_action( 'mmc_organization_branding_updated', self::get_branding(), $old );
        wp_safe_redirect( add_query_arg( 'mmc_branding_saved', '1', admin_url( 'admin.php?page=mmc-settings' ) ) );
        exit;
    }

    private static function handle_upload( $field ) {
        if ( empty( $_FILES[ $field ] ) || empty( $_FILES[ $field ]['name'] ) ) return null;
        $settings = self::get_settings();
        $file = $_FILES[ $field ];
        if ( ! empty( $file['size'] ) && (int) $file['size'] > ( absint( $settings['max_upload_mb'] ) * MB_IN_BYTES ) ) {
            return new WP_Error( 'mmc_upload_too_large', __( 'Immagine troppo grande.', 'membership-manager-core' ) );
        }
        $check = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'] );
        $mime = isset( $check['type'] ) ? $check['type'] : '';
        if ( ! in_array( $mime, $settings['allowed_mime_types'], true ) ) {
            return new WP_Error( 'mmc_upload_type_not_allowed', __( 'Tipo immagine non consentito.', 'membership-manager-core' ) );
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        $attachment_id = media_handle_upload( $field, 0, array( 'post_title' => 'membership-organization-brand-' . sanitize_key( $field ) ), array( 'test_form' => false ) );
        if ( is_wp_error( $attachment_id ) ) return $attachment_id;
        return array( 'id' => absint( $attachment_id ), 'url' => esc_url_raw( wp_get_attachment_url( $attachment_id ) ) );
    }
}

function mmc_get_organization_branding() {
    return MMC_Card_Profile_Service::get_branding();
}

function mmc_get_organization_branding_pass_fields() {
    return MMC_Card_Profile_Service::get_pass_fields();
}
