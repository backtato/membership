<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Public integration API for Membership Manager Core.
 *
 * Add-ons should prefer this class and the wrapper functions below instead of
 * calling internal repositories/services directly. This keeps the Core <-> Add-on
 * contract stable across future refactors.
 */
final class MMC_API {
    const CONTRACT_VERSION = '1.2.0';

    private function __construct() {}

    public static function contract_version() {
        return self::CONTRACT_VERSION;
    }

    public static function core_version() {
        return defined( 'MMC_VERSION' ) ? MMC_VERSION : '';
    }

    public static function manage_capability() {
        return mmc_cap_manage();
    }

    public static function get_member( $member_id ) {
        return class_exists( 'MMC_Member_Repository' ) ? MMC_Member_Repository::get( $member_id ) : null;
    }

    public static function get_member_by_email( $email ) {
        return class_exists( 'MMC_Member_Repository' ) ? MMC_Member_Repository::get_by_email( $email ) : null;
    }

    public static function upsert_member( array $data ) {
        if ( ! class_exists( 'MMC_Member_Repository' ) ) {
            return new WP_Error( 'mmc_core_not_ready', __( 'Membership Manager Core non è pronto.', 'membership-manager-core' ) );
        }
        return MMC_Member_Repository::upsert( $data );
    }

    public static function list_members( array $args = array() ) {
        return class_exists( 'MMC_Member_Repository' ) ? MMC_Member_Repository::list_members( $args ) : array();
    }

    public static function record_checkin( array $data ) {
        if ( ! class_exists( 'MMC_Checkin_Service' ) ) {
            return new WP_Error( 'mmc_core_not_ready', __( 'Membership Manager Core non è pronto.', 'membership-manager-core' ) );
        }
        return MMC_Checkin_Service::record( $data );
    }

    public static function get_next_event() {
        return class_exists( 'MMC_Events_Service' ) ? MMC_Events_Service::get_next_event() : null;
    }

    public static function get_card_provider() {
        $provider = apply_filters( 'mmc_card_provider', null );
        if ( $provider && $provider instanceof MMC_Card_Provider_Interface ) {
            return $provider;
        }
        return null;
    }

    public static function get_member_card_url( $member ) {
        $member = is_array( $member ) ? $member : array();
        $url = '';
        $provider = self::get_card_provider();
        if ( $provider ) {
            $candidate = $provider->get_card_url( $member );
            if ( is_string( $candidate ) ) {
                $url = esc_url_raw( $candidate );
            }
        }
        return apply_filters( 'mmc_member_card_url', $url, $member );
    }



    public static function get_expiry_settings() {
        return function_exists( 'mmc_get_expiry_settings' ) ? mmc_get_expiry_settings() : array();
    }

    public static function compute_expiry_date( $current_expiry = '', array $context = array() ) {
        return function_exists( 'mmc_compute_expiry_date' ) ? mmc_compute_expiry_date( $current_expiry, $context ) : '';
    }

    public static function generate_renew_url( $email, $base_url = '', array $args = array() ) {
        return function_exists( 'mmc_generate_renew_url' ) ? mmc_generate_renew_url( $email, $base_url, $args ) : '';
    }

    public static function validate_renew_request( $source = null, array $args = array() ) {
        if ( function_exists( 'mmc_validate_renew_request' ) ) {
            return mmc_validate_renew_request( $source, $args );
        }
        return new WP_Error( 'mmc_core_not_ready', __( 'Membership Manager Core non è pronto.', 'membership-manager-core' ) );
    }



    public static function get_organization_branding() {
        return class_exists( 'MMC_Card_Profile_Service' ) ? MMC_Card_Profile_Service::get_branding() : array();
    }

    public static function get_organization_branding_pass_fields() {
        return class_exists( 'MMC_Card_Profile_Service' ) ? MMC_Card_Profile_Service::get_pass_fields() : array();
    }

    public static function normalize_member_payload( array $data ) {
        $email = isset( $data['email'] ) ? mmc_clean_email( $data['email'] ) : '';
        return array(
            'wp_user_id'   => ! empty( $data['wp_user_id'] ) ? absint( $data['wp_user_id'] ) : null,
            'email'        => $email,
            'first_name'   => isset( $data['first_name'] ) ? sanitize_text_field( $data['first_name'] ) : '',
            'last_name'    => isset( $data['last_name'] ) ? sanitize_text_field( $data['last_name'] ) : '',
            'status'       => isset( $data['status'] ) ? sanitize_key( $data['status'] ) : '',
            'expiry_date'  => isset( $data['expiry_date'] ) ? sanitize_text_field( $data['expiry_date'] ) : '',
            'external_ref' => isset( $data['external_ref'] ) ? sanitize_text_field( $data['external_ref'] ) : '',
        );
    }
}

function mmc_api_contract_version() {
    return MMC_API::contract_version();
}

function mmc_get_member( $member_id ) {
    return MMC_API::get_member( $member_id );
}

function mmc_get_member_by_email( $email ) {
    return MMC_API::get_member_by_email( $email );
}

function mmc_upsert_member( array $data ) {
    return MMC_API::upsert_member( $data );
}

function mmc_list_members( array $args = array() ) {
    return MMC_API::list_members( $args );
}

function mmc_record_checkin( array $data ) {
    return MMC_API::record_checkin( $data );
}

function mmc_get_next_event() {
    return MMC_API::get_next_event();
}

function mmc_get_card_provider() {
    return MMC_API::get_card_provider();
}

function mmc_get_member_card_url( $member ) {
    return MMC_API::get_member_card_url( $member );
}


function mmc_api_get_expiry_settings() {
    return MMC_API::get_expiry_settings();
}

function mmc_api_compute_expiry_date( $current_expiry = '', array $context = array() ) {
    return MMC_API::compute_expiry_date( $current_expiry, $context );
}

function mmc_api_generate_renew_url( $email, $base_url = '', array $args = array() ) {
    return MMC_API::generate_renew_url( $email, $base_url, $args );
}

function mmc_api_validate_renew_request( $source = null, array $args = array() ) {
    return MMC_API::validate_renew_request( $source, $args );
}


function mmc_api_get_organization_branding() {
    return MMC_API::get_organization_branding();
}

function mmc_api_get_organization_branding_pass_fields() {
    return MMC_API::get_organization_branding_pass_fields();
}
