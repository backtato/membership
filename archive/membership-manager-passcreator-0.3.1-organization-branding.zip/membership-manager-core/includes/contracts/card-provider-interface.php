<?php
if ( ! defined( 'ABSPATH' ) ) exit;

interface MMC_Card_Provider_Interface {
    public function create_card( array $member );
    public function update_card( array $member );
    public function revoke_card( array $member );
    public function get_card_url( array $member );
}
