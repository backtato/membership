<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function mmc_table_members() {
    global $wpdb;
    return $wpdb->prefix . 'mmc_members';
}

function mmc_table_checkins() {
    global $wpdb;
    return $wpdb->prefix . 'mmc_checkins';
}

function mmc_cap_manage() {
    return apply_filters( 'mmc_cap_manage', 'manage_options' );
}

function mmc_clean_email( $email ) {
    return sanitize_email( strtolower( trim( (string) $email ) ) );
}

function mmc_member_status_from_expiry( $expiry_date ) {
    if ( empty( $expiry_date ) ) {
        return 'unknown';
    }
    $today = gmdate( 'Y-m-d' );
    return ( $expiry_date >= $today ) ? 'active' : 'expired';
}

function mmc_verify_admin_nonce( $action, $field = '_wpnonce' ) {
    return isset( $_REQUEST[ $field ] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_REQUEST[ $field ] ) ), $action );
}

function mmc_table_card_profiles() {
    global $wpdb;
    return $wpdb->prefix . 'mmc_card_profiles';
}
