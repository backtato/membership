<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Membership expiry and secure renewal-link engine.
 *
 * This is intentionally part of the Core contract: commerce add-ons should not
 * compute expiry dates on their own.
 */
class MMC_Expiry_Engine {
    public static function default_settings() {
        return array(
            'expiry_mode'                 => 'rolling_12_months',
            'rolling_months'              => 12,
            'extend_from_existing'        => 'yes',
            'fixed_year_month'            => 12,
            'fixed_year_day'              => 31,
            'late_renewal_next_year'      => 'yes',
            'late_renewal_month'          => 10,
            'fixed_date'                  => '',
            'renew_link_ttl_days'         => 14,
            'renew_email_param'           => 'mmc_renew_email',
            'renew_ts_param'              => 'mmc_renew_ts',
            'renew_sig_param'             => 'mmc_renew_sig',
        );
    }

    public static function get_settings() {
        $settings = get_option( 'mmc_expiry_settings', array() );
        if ( ! is_array( $settings ) ) {
            $settings = array();
        }
        $settings = wp_parse_args( $settings, self::default_settings() );
        return self::sanitize_settings( $settings );
    }

    public static function sanitize_settings( $settings ) {
        $settings = is_array( $settings ) ? $settings : array();
        $defaults = self::default_settings();
        $settings = wp_parse_args( $settings, $defaults );

        $modes = array( 'rolling_12_months', 'fixed_year_end', 'fixed_date' );
        $settings['expiry_mode'] = in_array( $settings['expiry_mode'], $modes, true ) ? $settings['expiry_mode'] : $defaults['expiry_mode'];
        $settings['rolling_months'] = max( 1, min( 120, absint( $settings['rolling_months'] ) ) );
        $settings['extend_from_existing'] = ( 'yes' === $settings['extend_from_existing'] ) ? 'yes' : 'no';
        $settings['fixed_year_month'] = max( 1, min( 12, absint( $settings['fixed_year_month'] ) ) );
        $settings['fixed_year_day'] = max( 1, min( 31, absint( $settings['fixed_year_day'] ) ) );
        $settings['late_renewal_next_year'] = ( 'yes' === $settings['late_renewal_next_year'] ) ? 'yes' : 'no';
        $settings['late_renewal_month'] = max( 1, min( 12, absint( $settings['late_renewal_month'] ) ) );
        $settings['fixed_date'] = self::sanitize_date( $settings['fixed_date'] );
        $settings['renew_link_ttl_days'] = max( 1, min( 90, absint( $settings['renew_link_ttl_days'] ) ) );
        $settings['renew_email_param'] = sanitize_key( $settings['renew_email_param'] ?: $defaults['renew_email_param'] );
        $settings['renew_ts_param'] = sanitize_key( $settings['renew_ts_param'] ?: $defaults['renew_ts_param'] );
        $settings['renew_sig_param'] = sanitize_key( $settings['renew_sig_param'] ?: $defaults['renew_sig_param'] );

        return $settings;
    }

    public static function sanitize_date( $date ) {
        $date = sanitize_text_field( (string) $date );
        if ( '' === $date ) return '';
        if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) return '';
        list( $year, $month, $day ) = array_map( 'absint', explode( '-', $date ) );
        return checkdate( $month, $day, $year ) ? sprintf( '%04d-%02d-%02d', $year, $month, $day ) : '';
    }

    public static function compute_expiry_date( $current_expiry = '', $context = array() ) {
        $settings = self::get_settings();
        $context = is_array( $context ) ? $context : array();
        $settings = apply_filters( 'mmc_expiry_settings_for_context', $settings, $current_expiry, $context );
        $settings = self::sanitize_settings( $settings );

        if ( ! empty( $context['mode'] ) ) {
            $settings['expiry_mode'] = sanitize_key( $context['mode'] );
        }
        if ( ! empty( $context['months'] ) ) {
            $settings['rolling_months'] = max( 1, min( 120, absint( $context['months'] ) ) );
        }

        $current_expiry = self::sanitize_date( $current_expiry );

        if ( 'fixed_date' === $settings['expiry_mode'] ) {
            return $settings['fixed_date'] ?: self::compute_rolling_expiry( $current_expiry, $settings );
        }

        if ( 'fixed_year_end' === $settings['expiry_mode'] ) {
            return self::compute_fixed_year_expiry( $current_expiry, $settings );
        }

        return self::compute_rolling_expiry( $current_expiry, $settings );
    }

    private static function timezone() {
        return function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'UTC' );
    }

    private static function now_date() {
        return new DateTimeImmutable( current_time( 'Y-m-d' ), self::timezone() );
    }

    private static function compute_rolling_expiry( $current_expiry, $settings ) {
        $base = self::now_date();
        if ( 'yes' === $settings['extend_from_existing'] && $current_expiry ) {
            $existing = DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', $current_expiry . ' 23:59:59', self::timezone() );
            if ( $existing && $existing > $base ) {
                $base = $existing;
            }
        }
        return $base->modify( '+' . absint( $settings['rolling_months'] ) . ' months' )->format( 'Y-m-d' );
    }

    private static function compute_fixed_year_expiry( $current_expiry, $settings ) {
        $today = self::now_date();
        $year = absint( $today->format( 'Y' ) );
        $month = absint( $settings['fixed_year_month'] );
        $day = min( absint( $settings['fixed_year_day'] ), self::days_in_month( $year, $month ) );
        $target = DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', sprintf( '%04d-%02d-%02d 23:59:59', $year, $month, $day ), self::timezone() );

        if ( ! $target ) {
            $target = DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', sprintf( '%04d-12-31 23:59:59', $year ), self::timezone() );
        }

        if ( $today > $target || ( 'yes' === $settings['late_renewal_next_year'] && absint( $today->format( 'n' ) ) >= absint( $settings['late_renewal_month'] ) ) ) {
            $year++;
            $day = min( absint( $settings['fixed_year_day'] ), self::days_in_month( $year, $month ) );
            $target = DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', sprintf( '%04d-%02d-%02d 23:59:59', $year, $month, $day ), self::timezone() );
        }

        if ( $current_expiry ) {
            $existing = DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', $current_expiry . ' 23:59:59', self::timezone() );
            if ( $existing && $target && $existing >= $target ) {
                $next_year = absint( $target->format( 'Y' ) ) + 1;
                $day = min( absint( $settings['fixed_year_day'] ), self::days_in_month( $next_year, $month ) );
                $target = DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', sprintf( '%04d-%02d-%02d 23:59:59', $next_year, $month, $day ), self::timezone() );
            }
        }

        return $target ? $target->format( 'Y-m-d' ) : self::compute_rolling_expiry( $current_expiry, $settings );
    }

    private static function days_in_month( $year, $month ) {
        return absint( gmdate( 't', strtotime( sprintf( '%04d-%02d-01', $year, $month ) ) ) );
    }

    public static function sign_renewal_payload( $email, $ts ) {
        $email = mmc_clean_email( $email );
        $ts = absint( $ts );
        if ( ! is_email( $email ) || ! $ts ) return '';
        return hash_hmac( 'sha256', $email . '|' . $ts, wp_salt( 'auth' ) );
    }

    public static function generate_renew_url( $email, $base_url = '', $args = array() ) {
        $email = mmc_clean_email( $email );
        if ( ! is_email( $email ) ) return '';
        $settings = self::get_settings();
        $args = is_array( $args ) ? $args : array();
        $email_param = ! empty( $args['email_param'] ) ? sanitize_key( $args['email_param'] ) : $settings['renew_email_param'];
        $ts_param = ! empty( $args['ts_param'] ) ? sanitize_key( $args['ts_param'] ) : $settings['renew_ts_param'];
        $sig_param = ! empty( $args['sig_param'] ) ? sanitize_key( $args['sig_param'] ) : $settings['renew_sig_param'];
        $ts = ! empty( $args['ts'] ) ? absint( $args['ts'] ) : current_time( 'timestamp' );
        $sig = self::sign_renewal_payload( $email, $ts );
        if ( ! $sig ) return '';
        $base_url = $base_url ? esc_url_raw( $base_url ) : home_url( '/' );
        $url = add_query_arg( array(
            $email_param => rawurlencode( $email ),
            $ts_param    => $ts,
            $sig_param   => $sig,
        ), $base_url );
        return esc_url_raw( apply_filters( 'mmc_generate_renew_url', $url, $email, $base_url, $args ) );
    }

    public static function validate_renew_request( $source = null, $args = array() ) {
        $settings = self::get_settings();
        $args = is_array( $args ) ? $args : array();
        $source = is_array( $source ) ? $source : $_GET;
        $email_param = ! empty( $args['email_param'] ) ? sanitize_key( $args['email_param'] ) : $settings['renew_email_param'];
        $ts_param = ! empty( $args['ts_param'] ) ? sanitize_key( $args['ts_param'] ) : $settings['renew_ts_param'];
        $sig_param = ! empty( $args['sig_param'] ) ? sanitize_key( $args['sig_param'] ) : $settings['renew_sig_param'];

        $email_raw = isset( $source[ $email_param ] ) ? wp_unslash( $source[ $email_param ] ) : '';
        $email = mmc_clean_email( rawurldecode( (string) $email_raw ) );
        $ts = isset( $source[ $ts_param ] ) ? absint( wp_unslash( $source[ $ts_param ] ) ) : 0;
        $sig = isset( $source[ $sig_param ] ) ? sanitize_text_field( wp_unslash( $source[ $sig_param ] ) ) : '';

        if ( ! is_email( $email ) || ! $ts || '' === $sig ) {
            return new WP_Error( 'mmc_renew_missing_params', __( 'Parametri di rinnovo mancanti o non validi.', 'membership-manager-core' ) );
        }

        $now = current_time( 'timestamp' );
        $ttl = DAY_IN_SECONDS * absint( $settings['renew_link_ttl_days'] );
        if ( $ts > ( $now + HOUR_IN_SECONDS ) || ( $now - $ts ) > $ttl ) {
            return new WP_Error( 'mmc_renew_expired', __( 'Link di rinnovo scaduto.', 'membership-manager-core' ) );
        }

        $expected = self::sign_renewal_payload( $email, $ts );
        if ( ! hash_equals( $expected, $sig ) ) {
            return new WP_Error( 'mmc_renew_bad_signature', __( 'Firma del link di rinnovo non valida.', 'membership-manager-core' ) );
        }

        return array(
            'email' => $email,
            'ts'    => $ts,
            'sig'   => $sig,
        );
    }
}

function mmc_get_expiry_settings() {
    return MMC_Expiry_Engine::get_settings();
}

function mmc_compute_expiry_date( $current_expiry = '', $context = array() ) {
    return MMC_Expiry_Engine::compute_expiry_date( $current_expiry, $context );
}

function mmc_generate_renew_url( $email, $base_url = '', $args = array() ) {
    return MMC_Expiry_Engine::generate_renew_url( $email, $base_url, $args );
}

function mmc_validate_renew_request( $source = null, $args = array() ) {
    return MMC_Expiry_Engine::validate_renew_request( $source, $args );
}
