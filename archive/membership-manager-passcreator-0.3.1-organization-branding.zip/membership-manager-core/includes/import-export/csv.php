<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MMC_Import_Export_CSV {
    public static function register() {
        add_action( 'admin_post_mmc_export_members', array( __CLASS__, 'export_members' ) );
    }

    public static function export_members() {
        if ( ! current_user_can( mmc_cap_manage() ) || ! mmc_verify_admin_nonce( 'mmc_export_members' ) ) {
            wp_die( esc_html__( 'Permesso negato.', 'membership-manager-core' ) );
        }

        $members = MMC_Member_Repository::list_members( array( 'limit' => 200 ) );
        nocache_headers();
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=members.csv' );
        $out = fopen( 'php://output', 'w' );
        fputcsv( $out, array( 'email', 'first_name', 'last_name', 'status', 'expiry_date' ) );
        foreach ( $members as $member ) {
            fputcsv( $out, array( $member['email'], $member['first_name'], $member['last_name'], $member['status'], $member['expiry_date'] ) );
        }
        fclose( $out );
        exit;
    }
}
