<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MMC_Activator {
    public static function activate() {
        self::create_tables();
        update_option( 'mmc_db_version', MMC_DB_VERSION, false );
        add_option( 'mmc_installed_at', time(), '', false );
        flush_rewrite_rules();
    }

    public static function deactivate() {
        flush_rewrite_rules();
    }

    public static function maybe_upgrade() {
        $installed = get_option( 'mmc_db_version', '0' );
        if ( version_compare( (string) $installed, MMC_DB_VERSION, '<' ) ) {
            self::create_tables();
            update_option( 'mmc_db_version', MMC_DB_VERSION, false );
        }
    }

    public static function create_tables() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset_collate = $wpdb->get_charset_collate();

        $members = mmc_table_members();
        $checkins = mmc_table_checkins();
        $sql_members = "CREATE TABLE {$members} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            wp_user_id bigint(20) unsigned NULL,
            email varchar(190) NOT NULL,
            first_name varchar(120) NOT NULL DEFAULT '',
            last_name varchar(120) NOT NULL DEFAULT '',
            status varchar(30) NOT NULL DEFAULT 'unknown',
            expiry_date date NULL,
            external_ref varchar(190) NOT NULL DEFAULT '',
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY email (email),
            KEY status (status),
            KEY expiry_date (expiry_date),
            KEY wp_user_id (wp_user_id)
        ) {$charset_collate};";

        $sql_checkins = "CREATE TABLE {$checkins} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            member_id bigint(20) unsigned NULL,
            email varchar(190) NOT NULL DEFAULT '',
            event_id varchar(190) NOT NULL DEFAULT '',
            event_label varchar(190) NOT NULL DEFAULT '',
            source varchar(50) NOT NULL DEFAULT 'qr',
            checked_in_at datetime NOT NULL,
            created_by bigint(20) unsigned NULL,
            context text NULL,
            PRIMARY KEY  (id),
            KEY member_id (member_id),
            KEY email (email),
            KEY event_id (event_id),
            KEY checked_in_at (checked_in_at)
        ) {$charset_collate};";

        dbDelta( $sql_members );
        dbDelta( $sql_checkins );
    }
}
