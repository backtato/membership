<?php
if ( ! defined( 'ABSPATH' ) ) exit;

final class MMC_Plugin {
    private static $instance = null;
    private $booted = false;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    public function boot() {
        if ( $this->booted ) {
            return;
        }
        $this->booted = true;

        $this->load_files();
        $this->register_hooks();
    }

    private function load_files() {
        $files = array(
            'includes/contracts/card-provider-interface.php',
            'includes/contracts/api.php',
            'includes/renewals/expiry-engine.php',
            'includes/card-profile/service.php',
            'includes/members/repository.php',
            'includes/checkin/service.php',
            'includes/events/service.php',
            'includes/privacy/privacy.php',
            'includes/import-export/csv.php',
            'admin/admin.php',
            'public/shortcodes.php',
        );

        foreach ( $files as $file ) {
            require_once MMC_PATH . $file;
        }
    }

    private function register_hooks() {
        MMC_Admin::register();
        MMC_Shortcodes::register();
        MMC_Privacy::register();
        MMC_Import_Export_CSV::register();

        add_action( 'rest_api_init', array( 'MMC_Checkin_Service', 'register_rest_routes' ) );
        add_action( 'init', array( 'MMC_Events_Service', 'register_event_post_type' ) );

        MMC_Activator::maybe_upgrade();

        do_action( 'mmc_contract_loaded', MMC_API::contract_version() );
        do_action( 'mmc_core_loaded' );
    }
}
