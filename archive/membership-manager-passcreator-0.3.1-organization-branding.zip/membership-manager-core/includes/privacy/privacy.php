<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MMC_Privacy {
    public static function register() {
        add_filter( 'wp_privacy_personal_data_exporters', array( __CLASS__, 'register_exporter' ) );
        add_filter( 'wp_privacy_personal_data_erasers', array( __CLASS__, 'register_eraser' ) );
        add_action( 'admin_init', array( __CLASS__, 'add_privacy_policy_content' ) );
    }

    public static function add_privacy_policy_content() {
        if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
            return;
        }

        $content = wp_kses_post( __( 'Membership Manager Core stores membership records such as email address, first name, last name, membership status, expiry date, and check-in records for events. The plugin does not send this data to external services by itself. External integrations, if installed as separate add-ons, may have their own privacy requirements.', 'membership-manager-core' ) );
        wp_add_privacy_policy_content( 'Membership Manager Core', wpautop( $content ) );
    }

    public static function register_exporter( $exporters ) {
        $exporters['membership-manager-core'] = array(
            'exporter_friendly_name' => __( 'Membership Manager Core', 'membership-manager-core' ),
            'callback'               => array( __CLASS__, 'export_data' ),
        );
        return $exporters;
    }

    public static function register_eraser( $erasers ) {
        $erasers['membership-manager-core'] = array(
            'eraser_friendly_name' => __( 'Membership Manager Core', 'membership-manager-core' ),
            'callback'             => array( __CLASS__, 'erase_data' ),
        );
        return $erasers;
    }

    public static function export_data( $email_address, $page = 1 ) {
        $member = MMC_Member_Repository::get_by_email( $email_address );
        $data = array();
        if ( $member ) {
            $data[] = array(
                'group_id'    => 'mmc-member',
                'group_label' => __( 'Dati socio', 'membership-manager-core' ),
                'item_id'     => 'member-' . absint( $member['id'] ),
                'data'        => array(
                    array( 'name' => __( 'Email', 'membership-manager-core' ), 'value' => $member['email'] ),
                    array( 'name' => __( 'Nome', 'membership-manager-core' ), 'value' => $member['first_name'] ),
                    array( 'name' => __( 'Cognome', 'membership-manager-core' ), 'value' => $member['last_name'] ),
                    array( 'name' => __( 'Stato', 'membership-manager-core' ), 'value' => $member['status'] ),
                    array( 'name' => __( 'Scadenza', 'membership-manager-core' ), 'value' => $member['expiry_date'] ),
                ),
            );
        }
        return array( 'data' => $data, 'done' => true );
    }

    public static function erase_data( $email_address, $page = 1 ) {
        global $wpdb;
        $email = mmc_clean_email( $email_address );
        if ( is_email( $email ) ) {
            $wpdb->delete( mmc_table_members(), array( 'email' => $email ) );
            $wpdb->delete( mmc_table_checkins(), array( 'email' => $email ) );
        }
        return array( 'items_removed' => true, 'items_retained' => false, 'messages' => array(), 'done' => true );
    }
}
