<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MMC_Member_Repository {
    public static function get_by_email( $email ) {
        global $wpdb;
        $email = mmc_clean_email( $email );
        if ( ! is_email( $email ) ) {
            return null;
        }
        $row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . mmc_table_members() . ' WHERE email = %s LIMIT 1', $email ), ARRAY_A );
        return $row ?: null;
    }

    public static function get( $id ) {
        global $wpdb;
        $id = absint( $id );
        if ( ! $id ) return null;
        $row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . mmc_table_members() . ' WHERE id = %d LIMIT 1', $id ), ARRAY_A );
        return $row ?: null;
    }

    public static function upsert( array $data ) {
        global $wpdb;
        $email = isset( $data['email'] ) ? mmc_clean_email( $data['email'] ) : '';
        if ( ! is_email( $email ) ) {
            return new WP_Error( 'mmc_invalid_email', __( 'Email non valida.', 'membership-manager-core' ) );
        }

        $expiry = ! empty( $data['expiry_date'] ) ? sanitize_text_field( $data['expiry_date'] ) : null;
        if ( $expiry && ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $expiry ) ) {
            return new WP_Error( 'mmc_invalid_expiry', __( 'Data scadenza non valida.', 'membership-manager-core' ) );
        }

        $now = current_time( 'mysql' );
        $payload = array(
            'wp_user_id'   => ! empty( $data['wp_user_id'] ) ? absint( $data['wp_user_id'] ) : null,
            'email'        => $email,
            'first_name'   => isset( $data['first_name'] ) ? sanitize_text_field( $data['first_name'] ) : '',
            'last_name'    => isset( $data['last_name'] ) ? sanitize_text_field( $data['last_name'] ) : '',
            'status'       => isset( $data['status'] ) ? sanitize_key( $data['status'] ) : mmc_member_status_from_expiry( $expiry ),
            'expiry_date'  => $expiry,
            'external_ref' => isset( $data['external_ref'] ) ? sanitize_text_field( $data['external_ref'] ) : '',
            'updated_at'   => $now,
        );

        $existing = self::get_by_email( $email );
        if ( $existing ) {
            $updated = $wpdb->update( mmc_table_members(), $payload, array( 'id' => absint( $existing['id'] ) ) );
            if ( false === $updated ) {
                return new WP_Error( 'mmc_update_failed', __( 'Aggiornamento socio non riuscito.', 'membership-manager-core' ) );
            }
            do_action( 'mmc_member_updated', absint( $existing['id'] ), $payload );
            return absint( $existing['id'] );
        }

        $payload['created_at'] = $now;
        $inserted = $wpdb->insert( mmc_table_members(), $payload );
        if ( ! $inserted ) {
            return new WP_Error( 'mmc_insert_failed', __( 'Creazione socio non riuscita.', 'membership-manager-core' ) );
        }
        $id = absint( $wpdb->insert_id );
        do_action( 'mmc_member_created', $id, $payload );
        return $id;
    }

    public static function list_members( $args = array() ) {
        global $wpdb;
        $defaults = array( 'limit' => 50, 'offset' => 0, 'status' => '' );
        $args = wp_parse_args( $args, $defaults );
        $limit = max( 1, min( 200, absint( $args['limit'] ) ) );
        $offset = max( 0, absint( $args['offset'] ) );

        if ( ! empty( $args['status'] ) ) {
            return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . mmc_table_members() . ' WHERE status = %s ORDER BY last_name ASC, first_name ASC LIMIT %d OFFSET %d', sanitize_key( $args['status'] ), $limit, $offset ), ARRAY_A );
        }

        return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . mmc_table_members() . ' ORDER BY last_name ASC, first_name ASC LIMIT %d OFFSET %d', $limit, $offset ), ARRAY_A );
    }
}
