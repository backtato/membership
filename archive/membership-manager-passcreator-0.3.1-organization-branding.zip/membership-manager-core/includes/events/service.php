<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MMC_Events_Service {
    public static function register_event_post_type() {
        if ( ! apply_filters( 'mmc_register_event_cpt', true ) ) {
            return;
        }

        register_post_type( 'mmc_event', array(
            'labels' => array(
                'name'          => __( 'Eventi', 'membership-manager-core' ),
                'singular_name' => __( 'Evento', 'membership-manager-core' ),
            ),
            'public'       => true,
            'show_ui'      => true,
            'show_in_rest' => true,
            'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail' ),
            'menu_icon'    => 'dashicons-calendar-alt',
        ) );
    }

    public static function get_next_event() {
        $now = current_time( 'timestamp' );
        $query = new WP_Query( array(
            'post_type'      => 'mmc_event',
            'posts_per_page' => 1,
            'post_status'    => 'publish',
            'meta_key'       => '_mmc_event_start_ts',
            'orderby'        => 'meta_value_num',
            'order'          => 'ASC',
            'meta_query'     => array(
                array(
                    'key'     => '_mmc_event_start_ts',
                    'value'   => $now,
                    'compare' => '>=',
                    'type'    => 'NUMERIC',
                ),
            ),
        ) );

        if ( empty( $query->posts ) ) {
            return null;
        }

        $post = $query->posts[0];
        return array(
            'id'       => 'cpt:mmc_event:' . $post->ID,
            'title'    => get_the_title( $post ),
            'start_ts' => absint( get_post_meta( $post->ID, '_mmc_event_start_ts', true ) ),
            'url'      => get_permalink( $post ),
            'location' => sanitize_text_field( get_post_meta( $post->ID, '_mmc_event_location', true ) ),
        );
    }
}
