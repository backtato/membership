<?php
/**
 * Plugin Name: Membership Manager Core
 * Description: Core pubblico per gestione soci, scadenze, eventi e QR check-in. Integrazioni esterne come Passcreator e WooCommerce devono vivere in add-on separati.
 * Version: 0.4.1
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Author: Membership Manager
 * Text Domain: membership-manager-core
 * Domain Path: /languages
 * License: GPLv2 or later
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'MMC_VERSION', '0.4.1' );
define( 'MMC_FILE', __FILE__ );
define( 'MMC_PATH', plugin_dir_path( __FILE__ ) );
define( 'MMC_URL', plugin_dir_url( __FILE__ ) );
define( 'MMC_DB_VERSION', '0.4.0' );

require_once MMC_PATH . 'includes/helpers.php';
require_once MMC_PATH . 'includes/activator.php';
require_once MMC_PATH . 'includes/plugin.php';

register_activation_hook( __FILE__, array( 'MMC_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'MMC_Activator', 'deactivate' ) );

add_action( 'plugins_loaded', static function() {
    load_plugin_textdomain( 'membership-manager-core', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
    MMC_Plugin::instance()->boot();
} );
