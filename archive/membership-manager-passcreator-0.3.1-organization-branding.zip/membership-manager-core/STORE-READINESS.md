# Store readiness checklist — Membership Manager Core 0.1.1

## Completed in this package

- Core separated from Passcreator and WooCommerce.
- No mandatory external API dependency.
- GPL-compatible plugin header.
- WordPress.org-style `readme.txt` added and expanded.
- Admin actions guarded by capability checks and nonces.
- Admin output escaped with `esc_html`, `esc_url`, and related WP escaping helpers.
- DB writes use `$wpdb->insert`, `$wpdb->update`, `$wpdb->delete`, or prepared reads.
- Uninstall is opt-in for destructive deletion.
- Privacy exporter and eraser are registered.
- Privacy policy helper text is registered.
- REST check-in endpoint requires the configured management capability.
- Duplicate check-in guard added with a filterable time window.
- Integration surface prepared through hooks and `MMC_Card_Provider_Interface`.

## Still required before actual WordPress.org submission

- Run the official Plugin Check plugin in a real WordPress install.
- Run PHPCS with WordPress Coding Standards.
- Add final screenshots in `/assets` for the WordPress.org listing.
- Replace temporary author/contributor metadata with the real WordPress.org username.
- Decide the final public slug and branding.
- Test on a clean WordPress install with `WP_DEBUG`, `WP_DEBUG_LOG`, and `SCRIPT_DEBUG` enabled.
- Test activation/deactivation/uninstall on single-site and multisite if multisite support is desired.
- Prepare translations or at least generate the `.pot` file.

## Strategic constraint

Do not reintroduce WooCommerce, Passcreator, campaign automation, geofence, Google Sheets or Mototicino-specific logic into the Core. Those features belong in add-ons.
